from gurobipy import *
import pandas as pd
import numpy as np
import datetime as datetime
import pickle

############################################################################

def Simulation(vehicle_list_name, gmm, Gmm, gmmh, Gmmh, year,\
               regulation = True,\
               robust = True, penalty = 'Exclusion', kpen = 5,\
               save_result = False, verbose = True,\
               stages = 1, bid_time = 'noon', symmetric = True):
    """
    Simulation(vehicle_list_name, gmm, Gmm, gmmh, Gmmh, year,\
            regulation = True,\
            robust = True, penalty = 'Exclusion', kpen = 5,\
            save_result = False, verbose = True,\
            stages = 1, bid_time = 'noon', symmetric = True)
    Computes the state-of-charge and cumulative profit at the end of each
    day of the 'year'.

    VEHICLE DEPENDENT INPUTS:
        vehicle_list_name: name of an .xlsx files that contains the following fields for each vehicle
        name:       name of the vehicle instance (-)
        charger:    charger power (kW)
        battery:    battery capacity (kWh)
        y_star:     state-of-charge target (%)
        p_star:     deviation penalty (EUR/kWh)
        d_distance: multiplier for yearly energy consumption for driving -
                        default is 2,000 kWh/yr or 10,000 km/yr
        py:         price for instantaneous charging (EUR/kWh)
        d_time:     driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day

    VEHICLE INDEPENDENT INPUTS:
        gmm:        activation period (h)
        Gmm:        regulation cycle (h)
        gmmh:       reduced activation period (h)
        Gmmh:       reduced regulation cycle (h)
        year:       element of {2015, 2016, 2017, 2018, 2019}
        regulation: active or not active on the regulation market
        robust:     constraint protection for gmm and Gmm if true,
                        and for gmmh and Gmmh otherwise
        penalty:    penalty for non-delivery of promised regulation power,
                        either "Exclusion" or "Fine"
        kpen:       penalty factor set by the TSO--multiplies the availabitity price
        save_result:whether or not to save the results in a .h5 file
        verbose:    whether or not to show comments
        stages:     planning stages either 1 or 2
        bid_time:   either 'noon' or 'midnight' on the previous day
        symmetric:  either 'true' or 'false', if 'true': xup = xdown

    OUTPUTS:
        profit_y0:  dictionary of a dataframe for each vehicle with the state-of-charge and the cumulative profit
                    at the end of each day as columns. Returns an error message
                    if the problem is infeasible.

        This dataframe is saved under the following name:
        str(year)+'_'+vehicle_list_name+"_"+str(gmm)+'gmm_'+str(Gmm)+'Gmm_'
            +str(penalty)+'_'+str(kpen)+'kpen_'
            +str(regulation)+'_regulation_'
            +str(robust)+'_robust_'+str(plan_losses)+'_plan_losses_'
            +str(stages)+'_stages_'+str(bid_time)+'_bid_time'+str(symmetric)+'_symmetric.h5'
    """
    # -------------------- Prepare simulation parameters -------------------
    # Load vehicle data
    vehicle_list = pd.read_excel('../_data/vehicle_list.xlsx', sheet_name = vehicle_list_name, index_col = 0)
    # Load data
    pr = pd.read_hdf('../_data/pr.h5')
    pa = pd.read_hdf('../_data/pa.h5')
    pb = pd.read_hdf('../_data/pb.h5')
    d = pd.read_hdf('../_data/ds.h5', key = 'd')
    s = pd.read_hdf('../_data/ds.h5', key = 's')

    # Select test days
    if year == 2015:
        T = pd.date_range('01-01-2015 00:00:00', '12-31-2015', freq='D')
        T_30min = pd.date_range('01-01-2015 00:00:00', '12-31-2015 23:30:00', freq='30min')
    elif year == 2016:
        T = pd.date_range('01-01-2016 00:00:00', '12-31-2016', freq='D')
        T_30min = pd.date_range('01-01-2016 00:00:00', '12-31-2016 23:30:00', freq='30min')
    elif year == 2017:
        T = pd.date_range('01-01-2017 00:00:00', '12-31-2017', freq='D')
        T_30min = pd.date_range('01-01-2017 00:00:00', '12-31-2017 23:30:00', freq='30min')
    elif year == 2018:
        T = pd.date_range('01-01-2018 00:00:00', '12-31-2018', freq='D')
        T_30min = pd.date_range('01-01-2018 00:00:00', '12-31-2018 23:30:00', freq='30min')
    elif year == 2019:
        T = pd.date_range('01-01-2019 00:00:00', '12-31-2019', freq='D')
        T_30min = pd.date_range('01-01-2019 00:00:00', '12-31-2019 23:30:00', freq='30min')

    # declare vehicle list container - could be done in parallel
    vl = dict()
    for idx in vehicle_list.index:
        # dict for each vehicle
        vl[idx] = dict()
        # add driving style
        d_time = str(vehicle_list.loc[idx, 'd_time'])
        vl[idx]['d'] = vehicle_list.loc[idx, 'd_distance'] * d[d_time]
        vl[idx]['s'] = s[d_time]
        # battery characteristics (kWh)
        vl[idx]['y_max'] = 0.8*vehicle_list.loc[idx, 'battery']
        vl[idx]['y_min'] = 0.2*vehicle_list.loc[idx, 'battery']
        # charger
        vl[idx]['charger'] = vehicle_list.loc[idx, 'charger']
        vl[idx]['discharger'] = vehicle_list.loc[idx, 'discharger']
        # efficiencies (-)
        vl[idx]['nc'] = vehicle_list.loc[idx, 'nc']
        vl[idx]['nd'] = vehicle_list.loc[idx, 'nd']
        vl[idx]['dn'] = 1/vl[idx]['nd'] - vl[idx]['nc']
        # Convert target state-of-charge from % to kWh
        vl[idx]['y_star'] = vehicle_list.loc[idx,'y_star'] * vehicle_list.loc[idx,'battery'] / 100
        # Read p_star
        vl[idx]['p_star'] = vehicle_list.loc[idx,'p_star']
        # fast charger penalty
        vl[idx]['py'] = vehicle_list.loc[idx,'py']
        # define 1stage value function
        vl[idx]['phi_1stage'] = pd.DataFrame({'slope': [vl[idx]['p_star'], -vl[idx]['p_star']],
                                              'intercept': [-vl[idx]['p_star']*vl[idx]['y_star'],
                                                             vl[idx]['p_star']*vl[idx]['y_star']]})
        # utility price
        vl[idx]['uprice'] = vehicle_list.loc[idx, 'uprice']
        # Declare result dataframe
        vl[idx]['profit_y0'] = pd.DataFrame(np.nan, index=T, columns = ['profit', 'y0',
                                    'y0_min', 'y0_hat_min', 'y0_hat_max', 'y0_max',
                                    'fast_charger'])
        vl[idx]['dec_soc'] = pd.DataFrame(np.nan, index=T_30min, columns = ['xb', 'xup', 'xdown','d', 'y'])
        # Set-up profit counter and bidding market
        vl[idx]['profit'] = 0
        # initialize state-of-charge estimates
        y_star = vl[idx]['y_star']
        vl[idx]['y0'] = y_star
        vl[idx]['y0_min'] = y_star; vl[idx]['y0_max'] = y_star; vl[idx]['y0_hat_min'] = y_star; vl[idx]['y0_hat_max'] = y_star
        # initialize market participation and feasibility
        vl[idx]['infeasible'] = False

    # declare aggregator container
    agg = dict() 
    agg['profit_y0'] = pd.DataFrame(np.nan, index=T, columns = ['profit', 'y0', 'y0_min', 'y0_hat_min', 'y0_hat_max', 'y0_max', 'exclusion', 'fast_charger'])
    agg['dec_soc'] = pd.DataFrame(np.nan, index=T_30min, columns = ['xb', 'xup', 'xdown','d', 'y'])
    agg['profit'] = 0

    # market the central planner participates on
    if regulation:
        market = 'regulation'
    else:
        market = 'utility'

    # cumulative profit counter
    profit = 0

    # Load the frequency deviation signal depending on the EU activation period
    if Gmm == 2.5:
        delta = pd.read_hdf('../_data/delta_Gmm_2pt5hours.h5')
    elif Gmm == 5:
        delta = pd.read_hdf('../_data/delta_Gmm_5hours.h5')
    else:
        if verbose:
            print('ERROR: Gmm must be either 2.5 or 5')
        return 'ERROR: Gmm must be either 2.5 or 5'

    # Time Discretization, Planning Horizon Length
    dt = 0.5            # hours - planning time resolution
    ddt = 10            # seconds - simulation time resolution
    K = int(24/dt)      # length of the planning horizon

    # Minimum frequency deviation resolution
    delta_res = 10 / 200 # 10 out of 200 mHz

    # save a copy of the original gamma for the name of the results datafile
    gmm_org = gmm
    Gmm_org = Gmm

    # Robustness
    if robust:
        gmm = gmm
        Gmm = Gmm
    else:
        gmm = gmmh
        Gmm = Gmmh

    # -------------------- Run the simulation ------------------------------
    for t_day in T:
        t = pd.date_range(t_day, periods = K, freq='30min')
        for v in vl.keys():
            # Utility Prices
            vl[v]['pb'] = pb.loc[t,vl[v]['uprice']]
            # Charger Characteristics (kW)
            vl[v]['yc_max'] = vl[v]['charger'] * vl[v]['s'][t]          # charging
            vl[v]['yd_max'] = vl[v]['discharger'] * vl[v]['s'][t]      # discharging
            # Assign initial state-of-charge to results dataframe
            # ~ profit_y0['y0'][t_day] = y0

            # step 1: compute value function
            # 1 planning stage
            if stages == 1:
                vl[v]['phi'] = vl[v]['phi_1stage']
            else:
                print("stages == "+str(stages)+" is not implemented; stages must be 1.")
        
        # step 2: optimize
        if market == 'regulation':
            res_bid = Reg(pr=pr, K=K, dt=dt, t=t,
                          vl = vl,
                          gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh, symmetric = symmetric)
            # Check whether the problem is infeasible:
            if res_bid['profit'] == 'Infeasible':
                if verbose:
                    print('ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.')
                    print('Abort simulation.')
                return 'ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.'

            # Calculate new state-of-charge if the bidding problem is feasible
            else:
                tt = pd.date_range(t_day, periods = K*dt/ddt*3600, freq='10s')
                res_soc = Calc_y0(t=t, tt=tt, dt=dt, ddt=ddt, vl = vl, res_bid = res_bid, \
                                   delta=delta.loc[tt,:], delta_res = delta_res,\
                                   K=K, gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh,\
                                   bid_time = bid_time, kpen = kpen, pa = pa['pa'].loc[t])
                # For degugging
#                print(res_soc['y0'])
                if verbose:
                    print(str(t_day.date()))
                    for v in vl.keys():
                        print(str(v) + ' --- ymin : ' +str(round(res_soc[v]['ymin'],2))+'kWh --- ymax : ' +str(round(res_soc[v]['ymax'],2))+'kWh')

                # Account for potential regulation fine
                if res_soc['aggregator']['fine'] > 0:
                    # Account for the penalty mechanisms
                    if penalty == 'Exclusion':
                        # Switch to the utility market
                        if verbose:
                            print('++++++++++++++++++++++++++++++++++++++++++++++++++++')
                            print(str(t_day.date()) +' Exclusion from regulation market')
                            print('++++++++++++++++++++++++++++++++++++++++++++++++++++')
                        market = 'utility'
                        agg['profit_y0'].loc[t_day, 'exclusion'] = 1

                    elif penalty == 'Fine':
                        if verbose:
                            print(str(t_day.date()) + ' Fine : ' + str(round(res_soc['aggregator']['fine'],2)) + 'EUR')
                    else:
                        if verbose:
                            print('ERROR: \'penalty\' must be either \'Exclusion\' or \'Fine\'')
                            print('Abort simulation.')
                        return 'ERROR: \'penalty\' must be either \'Exclusion\' or \'Fine\''

                else:
                    agg['profit_y0'].loc[t_day, ['exclusion', 'fine']] = [0, 0]                                          
                # For debugging
#                print('y0 : ' + str(y0))
#                print('y0_min : ' + str(y0_min))
#                print('y0_max : ' + str(y0_max))
#                print('y0_hat_min : ' + str(y0_hat_min))
#                print('y0_hat_max : ' + str(y0_hat_max))

        if market == 'utility':
            res_utl = Utl(K=K, dt=dt, t=t, vl=vl)
            if res_utl['agg']['profit'] == 'Infeasible':
                if verbose:
                    print('ERROR: Infeasible utility purchases. Check whether \'ds.d\' is too high.')
                    print('Abort simulation.')
                return 'ERROR: Infeasible utility purchases. Check whether \'ds.d\' is too high.'
                
        # Save results
        # regulation market ---------------------------------------------------
        if market == 'regulation':
            # Assign profits
            agg['profit_y0'].loc[t_day, 'profit'] = res_bid['profit'] - res_soc['aggregator']['d_m_penalty'] - res_soc['aggregator']['fine']
            agg['profit'] += res_bid['profit'] - res_soc['aggregator']['d_m_penalty'] - res_soc['aggregator']['fine']
            agg['profit_y0'].loc[t_day, 'fast_charger'] = res_soc['aggregator']['d_m_penalty']
            agg['profit_y0'].loc[t_day, 'fine'] = res_soc['aggregator']['fine']
            for v in vl.keys():
                vl[v]['profit_y0'].loc[t_day, 'profit'] = res_bid[v]['profit'] - res_soc[v]['d_m_penalty']
                vl[v]['profit_y0'].loc[t_day, 'fast_charger'] = res_soc[v]['d_m_penalty']
            # Assign new state-of-charge
            for y_idx in ['y0_min', 'y0_max', 'y0_hat_min', 'y0_hat_max', 'y0']:
                agg['profit_y0'].loc[t_day, y_idx] = sum(np.array(res_soc[v][y_idx]) for v in vl.keys())
                for v in vl.keys():
                    vl[v]['profit_y0'].loc[t_day, y_idx] = res_soc[v][y_idx]              
                    vl[v][y_idx] = res_soc[v][y_idx]
            # Assign market decisions
            for dec in ['xb', 'xup', 'xdown']:
                agg['dec_soc'].loc[t, dec] = sum(np.array(res_bid[v][dec]) for v in vl.keys())
                for v in vl.keys():
                    vl[v]['dec_soc'].loc[t, dec] = res_bid[v][dec]
            # Assign state-of-charge
            agg['dec_soc'].loc[t, 'y'] = sum(res_soc[v]['y'] for v in vl.keys())
            for v in vl.keys():
                vl[v]['dec_soc'].loc[t, 'y'] = res_soc[v]['y']
        # utility -------------------------------------------------------------
        elif market == 'utility':
            # Assign profits
            agg['profit_y0'].loc[t_day, 'profit'] = res_utl['agg']['profit']
            agg['profit'] += res_utl['agg']['profit']
            for v in vl.keys():
                vl[v]['profit_y0'].loc[t_day, 'profit'] = res_utl[v]['profit']
            # Assign new state-of-charge
            for y_idx in ['y0_min', 'y0_max', 'y0_hat_min', 'y0_hat_max', 'y0']:
                agg['profit_y0'].loc[t_day, y_idx] = sum(res_utl[v]['yT'] for v in vl.keys())
                for v in vl.keys():              
                    vl[v][y_idx] = res_utl[v]['yT']
                    vl[v]['profit_y0'].loc[t_day, y_idx] = res_utl[v]['yT']
            # Assign market decisions and state-of-charge
            for dec in ['xb', 'y']:
                agg['dec_soc'].loc[t, dec] = res_utl['agg'][dec]
                for v in vl.keys():
                    vl[v]['dec_soc'].loc[t, dec] = res_utl[v][dec]
        # Assign driving patterns
        agg['dec_soc'].loc[t, 'd'] = sum(vl[v]['d'].loc[t] for v in vl.keys())
        for v in vl.keys():
            vl[v]['dec_soc'].loc[t, 'd'] = vl[v]['d'].loc[t]

        # Progress statement
        if verbose:
            print(str(t_day.date()) + ' Profit: ' + str(round(agg['profit'],2)) + 'EUR')
            print(str(t_day.date()) + ' SOC: ' + str(round(agg['profit_y0'].loc[t_day, 'y0'],2)) + 'kWh')
            print('----------------------------------------------------')

    # -------------------- Save the results --------------------------------
    # runfile name
    fname = 'Results/'+str(year)+'_'\
                      +str(vehicle_list_name)+'_'\
                      +str(len(vl.keys()))+'vehs_'\
                      +str(gmm_org)+'gmm_'+str(Gmm_org)+'Gmm_'\
                      +str(penalty)+'_'+str(kpen)+'kpen_'\
                      +str(regulation)+'_regulation_'\
                      +str(robust)+'_robust_'\
                      +str(stages)+'_stages_'\
                      +str(bid_time)+'_bid_time_'\
                      +str(symmetric)+'_symmetric.pickle'
    # save results
    with open(fname, "wb") as fp:
        pickle.dump({'agg': agg, 'vl': vl}, fp, protocol=pickle.HIGHEST_PROTOCOL) 
    # read results
    # with open('Results/filename.pickle', 'rb') as handle:
    #     b = pickle.load(handle)
    # profit_y0.to_hdf(fname, key='profit_y0')
    # dec_soc.to_hdf(fname, key='dec_soc')
    # Return the results
    return agg, vl

############################################################################

def Calc_y0(t, tt, dt, ddt, vl, res_bid, delta, delta_res, K,\
            gmm, Gmm, gmmh, Gmmh, bid_time, kpen, pa):
    """
    Returns several measures of the state-of-charge at the end of the current day:
        'y0':         the true state-of-charge (kWh)
        'y0_min':     a conservative lower bound (kWh)
        'y0_max':     a conservative upper bound (kWh)
        'y0_hat_min': a less conservative lower bound (kWh)
        'y0_hat_max': a less conservative upper bound (kWh)
    In addition, it returns:
        'ymin':       the true minimum of the state-of-charge during the current day (kWh)
        'ymax':       the true maximum of the state-of-charge during the current day (kWh)
        'xr_m':       the amount of missing regulation power during each time interval (kW)
        'd_m':        the amount of missing power for driving during each time interval (kW)
    """

    # convert ddt into hours
    ddt = ddt/3600

    # initialize result dict
    res_soc = dict()

    # loop over every all vehicles (could be done in parallel)
    for v in vl.keys():
        # --------------------- Calculate the true state-of-charge -------------
        # build a dataframe of the market decisions for the current day
        df = pd.DataFrame({'xb': res_bid[v]['xb'], 'xup': res_bid[v]['xup'], 'xdown': res_bid[v]['xdown']}, index=t)
        df['d'] = vl[v]['d'][t]
        # ------
        # debug: print the dataset
        # print(df)
        # wait = input("Press Enter to continue.")
        # ------
        # resample the dataframe from a 30min to a 10s resolution
        df = df.reindex(index = tt, method='ffill')
        df['delta'] = delta
        # ------
        # debug: print the dataset
        # print(df)
        # wait = input("Press Enter to continue.")
        # ------
        # add columns for the power missing for frequency regulation and for driving
        df['xr_m_up'] = 0   # power missing for up-regulation
        df['xr_m_down'] = 0 # power missing for down-regulation
        df['d_m'] = 0    # power missing for driving
        # account for the lower and the upper bound on the battery state-of-charge
        df['y'] = np.nan # state-of-charge

        nc = vl[v]['nc']; nd = vl[v]['nd']; dn = vl[v]['dn']; nc_plan = nc; nd_plan = nd; dn_plan = dn

        # --------------------- Non-robust case: missing power is possible
        if (gmm/Gmm == gmmh/Gmmh) | (nc != nc_plan) | (nd != nd_plan):
            # calculate soc and penalties iteratively
            for idx in df.index:
                # calculate state-of-charge at idx-1
                if idx == df.index[0]:
                    y = vl[v]['y0']
                else:
                    y = df.y[idx - idx.freq]
                # case distinction: parking or driving
                if df.d[idx] == 0:  # parking
                    # nominal power consumption
                    x = df.xb[idx] + max(df.delta[idx], 0) * df.xdown[idx] - max(-df.delta[idx], 0) * df.xup[idx]
                    # real power consumption when charging (note that the vehicle
                    # ... is either charging or discharging but never both simultaneously)
                    # ... the factor 1.001 is for numerical stability
                    xhat = min( x, (1.001*vl[v]['y_max'] - y)/(nc * ddt) )
                    # real power consumption when discharging
                    # ... the factor 0.999 is for numerical stability
                    xhat = max( xhat, nd*(0.999*vl[v]['y_min'] - y)/ddt )
                    # missing reserve power
                    df.loc[idx, 'xr_m_up'] = max(xhat - x, 0) / max(abs(df.delta[idx]), delta_res) # up regulation: nominal x is smaller than actual x (discharge too much power)
                    df.loc[idx, 'xr_m_down'] = max(x - xhat, 0) / max(abs(df.delta[idx]), delta_res) # down regulation: nominal x is greater than actual x (charge too much power)
                    # update y
                    df.loc[idx, 'y'] = y + min(nc*xhat, xhat/nd) * ddt
                else: # driving
                    # real power available for driving
                    # the factor 0.999 is for numerical stability
                    dhat = min( df.d[idx], (y - 0.999*vl[v]['y_min'])/ddt )
                    # missing power for driving
                    df.loc[idx, 'd_m'] = df.d[idx] - dhat
                    # update y
                    df.loc[idx, 'y'] = y - dhat * ddt
        # --------------------- Robust case: missing power is impossible
        else:
            # calculate nominal charging
            yp = df['xb'] + np.maximum(df['delta'], 0) * df['xdown'] - np.maximum(-df['delta'], 0) * df['xup']
            # ... and discharging rates
            ym = - (df['xb'] + np.maximum(df['delta'], 0) * df['xdown'] - np.maximum(-df['delta'], 0) * df['xup'])
            # impose their non-negativity
            yp[yp < 0] = 0
            ym[ym < 0] = 0
            # update the state-of-charge accordingly
            df['y'] = np.cumsum(nc*yp - ym/nd - df.d) * ddt + vl[v]['y0']

        # --------------------- Calculate the bounds on the state-of-charge ----
        # observe state-of-charge at noon for the decision on new market bids
        if bid_time == 'noon':
            t_obs = tt[0] + datetime.timedelta(hours=12,minutes=00)
            y_obs = df['y'][t_obs-datetime.timedelta(seconds=10)]
            # resample the true state-of-charge dataframe to a 30min resolution
            df_dt = df.resample('30min').mean()
            # define the time range at the end of which the bounds on the
            # ... state-of-charge should hold
            t_est = pd.date_range(t_obs, t[-1], freq='30min')
            # extract the values of the market bids and the power consumption for
            # ... driving for that time range
            d = df_dt.d[t_est]
            xb = np.array(df_dt.xb[t_est].values)
            xup = np.array(df_dt.xup[t_est].values)
            xdown = np.array(df_dt.xdown[t_est].values)
            # Estimate the conservative bounds
            y0_max = Calc_y0_max(dt, d, xdown, xb, y_obs, nc_plan, gmm, Gmm)
            y0_min = Calc_y0_min(dt, d, xup, xb, y_obs, nc_plan, dn_plan, gmm, Gmm)
            # Estimate the less conservative bounds
            y0_hat_max = Calc_y0_max(dt, d, xdown, xb, y_obs, nc_plan, gmmh, Gmmh)
            y0_hat_min = Calc_y0_min(dt, d, xup, xb, y_obs, nc_plan, dn_plan, gmmh, Gmmh)
            # bound the forecasts by the lower and upper bounds on the batter capacity
            y0_min = max(y0_min, vl[v]['y_min'])
            y0_hat_min = max(y0_hat_min, vl[v]['y_min'])
            y0_max = min(y0_max, vl[v]['y_max'])
            y0_hat_max = min(y0_hat_max, vl[v]['y_max'])
        elif bid_time == 'midnight':
            # resample the true state-of-charge dataframe to a 30min resolution
            df_dt = df.resample('30min').mean()
            # calculate the bounds
            y0_min = df['y'][-1]
            y0_hat_min = df['y'][-1]
            y0_max = df['y'][-1]
            y0_hat_max = df['y'][-1]

        # --------------------- Compute fast-charging penalty ----
        d_m_penalty = dt * sum( df_dt['d_m'] * vl[v]['py'] )

        # log results
        res_soc[v] = {'y0': df['y'][-1], 'y0_min': y0_min, 'y0_max': y0_max,\
            'y0_hat_min': y0_hat_min, 'y0_hat_max': y0_hat_max,\
            'ymin': df['y'].min(), 'ymax': df['y'].max(), 'y': df.loc[t, 'y'],\
            'xr_m_up': df_dt['xr_m_up'], 'xr_m_down': df_dt['xr_m_down'], 'd_m': df_dt['d_m'],\
            'd_m_penalty': d_m_penalty}

    # --------------------- Compute aggregator level imbalance penalty -----
    xr_m_up = sum( res_soc[v]['xr_m_up'] for v in vl.keys() )
    xr_m_down = sum( res_soc[v]['xr_m_down'] for v in vl.keys() )
    fine = dt * sum( np.maximum(xr_m_up, xr_m_down) * kpen * pa )
    d_m_penalty = sum(res_soc[v]['d_m_penalty'] for v in vl.keys())
    # log results
    res_soc['aggregator'] = {'xr_m_up': xr_m_up, 'xr_m_down': xr_m_down, 'fine': fine, 'd_m_penalty': d_m_penalty}
    # --------------------- Return the results -----------------------------
    return res_soc

############################################################################

def Calc_y0_max(dt, d, xdown, xb, y0_obs, nc, gmm, Gmm):

#    print('Forecast upper bound on state-of-charge')

    k = len(xdown)
#    print('k : '+str(k))

    # Gurobi Model
    m = Model("y0_max")
    # Maximization
    m.ModelSense = -1
    # Decision Variables
    delta = m.addVars(range(k), lb=0, ub=1, obj=nc*xdown, name="delta")
    # Constraints
#    for l in range(k):
#        print(str(max(0, l+1 - round(Gmm/dt))) + '--' + str(l))
    m.addConstrs( (quicksum( delta[i] \
                    for i in range( max(0, l+1 - round(Gmm/dt)), l+1)) \
                    <= round(gmm/dt) for l in range(k)), "ymax" )
    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Optimize
    m.optimize()

#    print('obj_val_ymax : ' + str(m.objVal))
#    print('y0_obs : ' + str(y0_obs))
    return y0_obs + (sum(nc*xb - d) + m.objVal)*dt

############################################################################

def Calc_y0_min(dt, d, xup, xb, y0_obs, nc, dn, gmm, Gmm):

#    print('Forecast lower bound on state-of-charge')

    k = len(xup)
#    print('k : '+str(k))
    # Gurobi Model
    m = Model("y0_min")
    # Maximization
    m.ModelSense = -1
    # Decision Variables
    delta = m.addVars(range(k), lb=0, ub=1,\
                      obj= (nc*xup + dn*np.maximum(xup-xb,0)) , name="delta")
    # Constraints
#    for l in range(k):
#        print(str(max(0, l+1 - round(Gmm/dt))) + '--' + str(l))
    m.addConstrs( (quicksum( delta[i] \
                            for i in range( max(0, l+1 - round(Gmm/dt)), l+1)) \
                    <= round(gmm/dt) for l in range(k)), "ymin" )
    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Optimize
    m.optimize()

#    print('obj_val_ymin : ' + str(m.objVal))
    return y0_obs + (sum(nc*xb - d) - m.objVal)*dt

############################################################################

def Reg(pr, K, dt, t, vl, gmm, Gmm, gmmh, Gmmh, symmetric = True):

#    print('Build optimization problem')

    # Build tuplelists
    idx_v = [(v) for v in vl.keys()]
    idx_vk = [(v,k) for v in vl.keys() for k in range(K)]
    idx_vkl = [(v,k,l) for v in vl.keys() for k in range(K) for l in range(k+1)]
    idx_vnpos = [(v,n) for v in vl.keys() for n in vl[v]['phi'][vl[v]['phi'].slope >= 0].index.tolist()]
    idx_vnneg = [(v,n) for v in vl.keys() for n in vl[v]['phi'][vl[v]['phi'].slope < 0].index.tolist()]

    # construct utility price vector
    pb = []
    for v in vl.keys():
        pb.extend(vl[v]['pb'])
    pb = np.array(pb)

    # Setup Optimization Model
    m = Model("Reg_centralized")

    # Decision Variables and Objective (debug on real regulation prices)
    xup = m.addVars(idx_vk, lb=0, obj=-dt*np.repeat(pr.loc[t, 'up_est'], len(vl.keys())), name="xup")
    xdown = m.addVars(idx_vk, lb=0, obj=-dt*np.repeat(pr.loc[t, 'down_est'], len(vl.keys())), name="xdown")
    xb = m.addVars(idx_vk, lb=0, obj=dt*pb, name="xb")
    yTlh = m.addVars(idx_v, lb = -GRB.INFINITY, name = 'yTlh')
    yTuh = m.addVars(idx_v, lb = -GRB.INFINITY, name = 'yTuh')
    z = m.addVars(idx_v, obj=1, lb=-GRB.INFINITY, name="z")
    # Decision Rule Coefficients
    b = m.addVars(idx_vk, lb=-GRB.INFINITY, name="b")
    # Dual Variables - Vectors
    lbdp = m.addVars(idx_vk, lb=0, name="lbdp")
    lbdm = m.addVars(idx_vk, lb=0, name="lbdlm")
    thtp = m.addVars(idx_vk, lb=0, name="thtp")
    thtm = m.addVars(idx_vk, lb=0, name="thtm")
    # Dual Variables - Matrices
    Lbdp = m.addVars(idx_vkl, lb=0, name="Lbdp")
    Lbdm = m.addVars(idx_vkl, lb=0, name="Lbdm")
    Thtp = m.addVars(idx_vkl, lb=0, name="Thtp")
    Thtm = m.addVars(idx_vkl, lb=0, name="Thtm")

    # Power Constraints
    m.addConstrs( (xdown[v,k] + xb[v,k] <= vl[v]['yc_max'][k] for (v,k) in idx_vk), "cmax" )
    m.addConstrs( (xup[v,k] - xb[v,k] <= vl[v]['yd_max'][k] for (v,k) in idx_vk), "dmax" )

    # Linearization Constraints
    m.addConstrs( (b[v,k] >= vl[v]['nc']*xup[v,k] for (v,k) in idx_vk ), "LDR_1" )
    m.addConstrs( (b[v,k] >= xup[v,k]/vl[v]['nd'] - vl[v]['dn']*xb[v,k] for (v,k) in idx_vk ), "LDR_2" )

    # Energy Constraints
    m.addConstrs( ( vl[v]['y_max'] - (quicksum( dt*(vl[v]['nc']*xb[v,l] + Lbdp[v,k,l] - vl[v]['d'][t][l] ) \
                              + gmm*Thtp[v,k,l] for l in range(k+1) ))\
                     >= vl[v]['y0_max'] for (v,k) in idx_vk), "ymax")

    m.addConstrs( ( vl[v]['y_min'] - (quicksum( dt*(vl[v]['nc']*xb[v,l] - Lbdm[v,k,l] - vl[v]['d'][t][l] ) \
                              - gmm*Thtm[v,k,l] for l in range(k+1) ))\
                     <= vl[v]['y0_min'] for (v,k) in idx_vk), "ymin")

    # Epigraph constraints
    # add epigraph constraints
    m.addConstrs( ( vl[v]['phi'].slope.loc[n] * yTlh[v] + vl[v]['phi'].intercept.loc[n] <= z[v] \
                    for (v,n) in idx_vnneg), "z_neg")
    m.addConstrs( ( vl[v]['phi'].slope.loc[n] * yTuh[v] + vl[v]['phi'].intercept.loc[n] <= z[v] \
                    for (v,n) in idx_vnpos), "z_pos")

    # Bounds on the deviation from the initial state-of-charge
    m.addConstrs( (yTuh[v] - quicksum( dt*(vl[v]['nc']*xb[v,k] + lbdp[v,k] - vl[v]['d'][t][k] ) + gmmh*thtp[v,k] \
                          for k in range(K))\
                >= vl[v]['y0_hat_max'] for v in idx_v), 'zh')

    m.addConstrs( (yTlh[v] - quicksum( dt*(vl[v]['nc']*xb[v,k] - lbdm[v,k] - vl[v]['d'][t][k]) - gmmh*thtm[v,k]\
                          for k in range(K))\
                <= vl[v]['y0_hat_min'] for v in idx_v), 'zl')

    # Constraints from Dualization
    m.addConstrs( (Lbdp[v,k,l] + quicksum( Thtp[v,k,i] \
                   for i in range(l, 1+I(k, l, Gmm, dt))) \
                   >= vl[v]['nc']*xdown[v,l] for (v,k,l) in idx_vkl), "dual_yp")

    m.addConstrs( (Lbdm[v,k,l] + quicksum( Thtm[v,k,i] \
                   for i in range(l, 1+I(k, l, Gmm, dt))) \
                   >= b[v,l] for (v,k,l) in idx_vkl), "dual_ym")

    m.addConstrs( (lbdp[v,k] + quicksum( thtp[v,i] \
                   for i in range(k, 1+I(K-1, k, Gmmh, dt))) \
                   >= vl[v]['nc']*xdown[v,k] for (v,k) in idx_vk), "dual_yph")

    m.addConstrs( (lbdm[v,k] + quicksum( thtm[v,i] \
                   for i in range(k, 1+I(K-1, k, Gmmh, dt))) \
                   >= b[v,k] for (v,k) in idx_vk), "dual_ymh")

    # Symmetry constraint
    if symmetric:
        m.addConstrs( ( quicksum( xup[v,k] - xdown[v,k] for v in idx_v) == 0 for k in range(K)), "symmetry" )

    # Disable logging to screen
    m.Params.OutputFlag = 0

#    print('Solve optimization problem')

#   Solve with dual simplex method
    m.Params.Method = 1
    m.optimize()

#    print('Retrieve solution')
#    print('z: '+str(z.X))
    # Update optimal solution

    res_bid = dict()
    if m.status == 2:
        for v in idx_v:
            res_bid[v] = dict()
            # Read optimal variables
            res_bid[v]['xup'] = []
            res_bid[v]['xdown'] = []
            res_bid[v]['xb'] = []
            for k in range(0,K):
                res_bid[v]['xup'].append(xup[v,k].X)
                res_bid[v]['xdown'].append(xdown[v,k].X)
                res_bid[v]['xb'].append(xb[v,k].X)
            # Evaluate profit per vehicle
            res_bid[v]['profit'] = dt*sum(pr.loc[t, 'up'][k] * res_bid[v]['xup'][k] 
                                 + pr.loc[t, 'down'][k] * res_bid[v]['xdown'][k] 
                                 - vl[v]['pb'][k] * res_bid[v]['xb'][k] for k in range(K))
        # Evaluate profit on real prices
        res_bid['profit'] = sum(res_bid[v]['profit'] for v in idx_v)
        # Log profit for comparison
        res_bid['obj'] = m.objval
        # only needed for multi-stage value function estimation - not (yet) implemented
        # # Calculate slope wrt to y0
        # # list relevant constraint names
        # c_names = ['zl', 'zh']
        # c_names_k = ['ymin', 'ymax']
        # for i in c_names_k:
        #     for k in range(K):
        #         c_names.append(i+'['+str(k)+']')
# 
        # dobj_dy0 = 0
        # for i in c_names:
        #     dobj_dy0 = dobj_dy0 + m.getConstrByName(i).Pi
        # return {'obj': m.objval, 'dobj_dy0': dobj_dy0, \
        # 'profit': profit, 'xup': xup_sol, 'xdown': xdown_sol, 'xb': xb_sol}
        return res_bid
    # Check for infeasibility
    else:
        res_bid['profit'] = 'Infeasible'
        return res_bid

############################################################################

def I(k,l,Gmm,dt):
    return round(min(k, l + Gmm/dt - 1))

############################################################################

def Utl(K, dt, t, vl):
    # Build tuplelists
    idx_v = [(v) for v in vl.keys()]
    idx_vk = [(v,k) for v in vl.keys() for k in range(K)]
    idx_vn = [(v,n) for v in vl.keys() for n in vl[v]['phi'].index.tolist()]

    # construct utility price and charging capacity vector
    pb = []; yc_max = []
    for v in vl.keys():
        pb.extend(vl[v]['pb'])
        yc_max.extend(vl[v]['yc_max'])
    pb = np.array(pb); yc_max = np.array(yc_max)

    # Setup Optimization Model
    m = Model("Utl")

    # Decision Variables and Objective
    xb = m.addVars(idx_vk, lb=0, ub=yc_max, obj=dt*pb, name='xb')
    yT = m.addVars(idx_v, lb = -GRB.INFINITY, name = 'yT')
    z = m.addVars(idx_v, obj=1, name='z')

    # Constraints
    m.addConstrs( ( vl[v]['y_max'] - dt * quicksum( vl[v]['nc']*xb[v,l] - vl[v]['d'][t][l] for l in range(k+1) ) \
                   >= vl[v]['y0'] for (v,k) in idx_vk), 'ymax')
    m.addConstrs( ( vl[v]['y_min'] - dt * quicksum( vl[v]['nc']*xb[v,l] - vl[v]['d'][t][l] for l in range(k+1) ) \
                   <= vl[v]['y0'] for (v,k) in idx_vk), 'ymin')

    # Epigraph constraints
    m.addConstrs( ( vl[v]['phi'].slope.loc[n] * yT[v] + vl[v]['phi'].intercept.loc[n] <= z[v] \
                    for (v,n) in idx_vn), "z")

    # Terminal State-of-Charge
    m.addConstrs( (yT[v] - quicksum( dt*(vl[v]['nc']*xb[v,k] - vl[v]['d'][t][k]) for k in range(K) ) \
                    == vl[v]['y0'] for v in idx_v), 'yT' )

    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Solve with dual simplex method
    m.Params.Method = 1
    m.optimize()

    # read results
    res_utl = dict()
    res_utl['agg'] = dict()
    # Check for infeasibility
    if m.status != 2:
        res_utl['agg']['profit'] = 'Infeasible'
        return res_utl
    else:
        for v in idx_v:
            res_utl[v] = dict()
            # Update optimal solution--extract decision variables
            res_utl[v]['xb'] = []
            for k in range(0,K):
                res_utl[v]['xb'].append(xb[v,k].X)
            # Evaluate profit and terminal state-of-charge
            res_utl[v]['profit'] = -dt*sum(vl[v]['pb'] * res_utl[v]['xb'])
            res_utl[v]['yT'] = vl[v]['y0'] + dt*sum(vl[v]['nc']*np.array(res_utl[v]['xb']) - np.array(vl[v]['d'][t]))
            # Compute and log state-of-charge trajectory
            df = pd.DataFrame({'xb': res_utl[v]['xb'], 'd': vl[v]['d'][t]})
            df['y'] = vl[v]['y0'] + dt*(vl[v]['nc']*df.xb.cumsum() - df.d.cumsum())
            res_utl[v]['y'] = df['y']

        # aggregator variables
        for idx in ['profit', 'xb', 'y']:
            res_utl['agg'][idx] = sum(np.array(res_utl[v][idx]) for v in idx_v)
                
    return res_utl                         
############################################################################