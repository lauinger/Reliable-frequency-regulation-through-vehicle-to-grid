import time
import os, sys
import pandas as pd
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)
from my_functions_aggregator import Simulation

# --------------- VEHICLE DEPENDENT PARAMETER LIST --------------------
vehicle_list_name = "vehicle_fleet" # Run aggregator for a fleet with 9 vehicles and symmetric bidding only imposed at aggregator level
vehicle_list_name = "uni_base"      # Run aggregator for a fleet with 2 vehicles: (1) base vehicle, (2) base vehicle with unidirectional charging

# --------------- VEHICLE INDEPENDENT PARAMETER LIST ------------------
# Planning stages
stages = 1
# Simulation year in {2015, 2016, 2017, 2018, 2019}
year = 2019
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty for non-delivery of regulation power: either 'Exclusion' or 'Fine'
penalty = 'Fine'
# Penalty parameters for the calculation of the fine
kpen = 65 # Penalty factor (-)
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'

# ------------ Boolean Variables
regulation = True
robust = True
symmetric = True
# ------------ Save results and verbose
save_result = True
verbose = True

# --------------- RUN THE SIMULATION ------------------
print('------------------------------------')
print('Year: '+str(year)+', vehicle list: '+vehicle_list_name)
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh))
print('Penalty: '+penalty+', kpen: '+str(kpen))
print('Regulation: '+str(regulation)
      +', Robust: '+str(robust)
      +', Stages: '+str(stages))
print('Symmetric: ' + str(symmetric))
print('------------------------------------')

# begin time measurement
start = time.time()

agg, vl = Simulation(vehicle_list_name, gmm, Gmm, gmmh, Gmmh,
                        year, regulation, robust, penalty, kpen,
                        save_result, verbose, stages,
                        bid_time, symmetric)

# end time measurement
end = time.time()
print('------------------------------------')
# ~ print('Execution time : '+str(round((end - start)/60))+'min')
print('Execution time : '+str(round((end - start)))+'s')
print('------------------------------------')
