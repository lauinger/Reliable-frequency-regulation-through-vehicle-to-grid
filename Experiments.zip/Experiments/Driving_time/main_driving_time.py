# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('---------- DRIVING TIME SIMULATION ---------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Hours driven per day
d_Times = 1 + np.arange(22)
# d_Times = np.array([22])
# Battery and charger size
# delivery guarantee 
# anticipative and non-anticipative (all in Scenarios definition below)
# Scenarios = ['base', 'base_anticipative', '100kWh_7kW_30min', '100kWh_11kW_30min', '100kWh_11kW_15min']

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Simulation year in {2015, 2016, 2017, 2018, 2019}
year_test = 2019
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.10]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# EU activation period in h
gmm = 0.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Save results and verbose
save_result = True
verbose = False
# Base-case scenario
penalty = 'Exclusion'
losses = True
uni = False
regulation = True
robust = True
plan_losses = True

print('Common parameters:')
print('Year (test): '+str(year_test))
print('gmm: '+str(gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving distance: '+str(d_distance))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Uni: '+str(uni)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
Scenarios = ['base', 'base_anticipative', '100kWh_7kW_30min', '100kWh_11kW_30min', '100kWh_11kW_15min']
Bid_types = ['reg']
Refs = ['ref']
# create result dataframes
cnames = [Bid_types + Refs, Scenarios]
profits = pd.DataFrame(columns = pd.MultiIndex.from_product(cnames))
value_v2g = pd.DataFrame(columns = Scenarios)
# loop over driving_time
for d_time in d_Times:
    # loop over scenario
    for (b_type, scenario) in profits.columns:
        print('---------------------------------------------------')
        print('Driving time: '+str(d_time)+'h, scenario: '+scenario+' -- '+b_type)
        print('---------------------------------------------------')
        # case distinction: b_type
        if b_type == 'reg':
            regulation = True
        elif b_type == 'ref':
            regulation = False
        # case distinction: scenario
        # -- base
        if scenario == 'base':
            year_train = year_test - 1
            battery = 50
            charger = 7
            Gmm = 2.5
        # -- base anticipative
        elif scenario == 'base_anticipative':
            year_train = year_test
            battery = 50
            charger = 7
            Gmm = 2.5
        # -- 100kWh_7kW_30min
        elif scenario == '100kWh_7kW_30min':
            year_train = year_test - 1
            battery = 100
            charger = 7
            Gmm = 2.5
        # -- 100kWh_11kW_30min
        elif scenario == '100kWh_11kW_30min':
            year_train = year_test - 1
            battery = 100
            charger = 11
            Gmm = 2.5
        # -- 100kWh_11kW_15min
        elif scenario == '100kWh_11kW_15min':
            year_train = year_test - 1
            battery = 100
            charger = 11
            Gmm = 5
        # --------------- RUN THE SIMULATION ------------------
        HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                             year_train, d_distance, uni, losses, regulation, robust, penalty,
                             kpen, py, plan_losses, save_result, sweep, stages,
                             d_time, bid_time)
        # --------------- EXTRACT RESULTS ------------------
        if HM.isnull().all().all():
            profits.loc[d_time, (b_type, scenario)] = np.nan
        else:
            # find best tuple p and y
            ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
            p_star = HM.columns[ci]
            y_star = HM.index[ri]
            # --------------- EVALUATE ON TEST YEAR ------------------
            profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
            # Check for error message
            if type(profit_y0) == str:
                profits.loc[d_time, (b_type, scenario)] = np.nan
            else:
                # assign cost to relevant dataframe
                profits.loc[d_time, (b_type, scenario)] = round(profit_y0['Profit'].values[-1],2)
    # compute profit
    for scenario in Scenarios:
        value_v2g.loc[d_time, scenario] = round(profits.loc[d_time, ('reg', scenario)] - profits.loc[d_time, ('ref', scenario)],2)
# --------------------------------------------------
# save profits and value_v2g
fname = 'driving_time.h5'
# - profits
profits.applymap(str).to_hdf(fname, key='profits', mode = 'w', format = 'table')
# - value_v2g
value_v2g.applymap(str).to_hdf(fname, key='value_v2g', mode = 'a', format = 'table')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')