# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('----------- DRIVING DISTANCE SIMULATION -----------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Driving distance (1 corresponds to 10,000 km)
d_Distances = np.arange(4.25, step=0.25)
# d_Distances = [4]
# Unidirectional charging 
# Battery and charger size
# delivery guarantee 
# anticipative and non-anticipative (all in Scenarios definition below)
# Scenarios = ['base', 'base_anticipative', '100kWh_7kW_30min', '100kWh_11kW_30min', '100kWh_11kW_15min']

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Testing year in {2015, 2016, 2017, 2018, 2019}
year_test = 2019
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.1]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Save results and verbose
save_result = True
verbose = False
# Base-case scenario
penalty = 'Exclusion'
losses = True
regulation = True
robust = True
plan_losses = True

print('Common parameters:')
print('Year (test): '+str(year_test))
print('gmm: '+str(gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving time: '+str(d_time))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
Scenarios = ['base', 'base_anticipative', '100kWh_7kW_30min', '100kWh_11kW_30min', '100kWh_11kW_15min']
# Scenarios = ['base']
Charger_types = ['bi', 'uni']
Refs = ['ref']
# create result dataframes
cnames = [Charger_types + Refs, Scenarios]
profits = pd.DataFrame(columns = pd.MultiIndex.from_product(cnames))
cnames = [Charger_types, Scenarios]
value_v2g = pd.DataFrame(columns = pd.MultiIndex.from_product(cnames))
# loop over driving distance
for d_distance in d_Distances:
    # loop over scenarios
    for (c_type, scenario) in profits.columns:
        print('---------------------------------------------------')
        print('Driving distance: '+str(d_distance)+', scenario: '+scenario+' -- '+c_type)
        print('---------------------------------------------------')
        # case distinction: c_type
        if c_type == 'bi':
            uni = False
            regulation = True
        elif c_type == 'uni':
            uni = True
            regulation = True
        elif c_type == 'ref':
            uni = False
            regulation = False
        # case distinction: scenario
        # -- base
        if scenario == 'base':
            year_train = year_test - 1
            battery = 50
            charger = 7
            Gmm = 2.5
        # -- base anticipative
        elif scenario == 'base_anticipative':
            year_train = year_test
            battery = 50
            charger = 7
            Gmm = 2.5
        # -- 100kWh_7kW_30min
        elif scenario == '100kWh_7kW_30min':
            year_train = year_test - 1
            battery = 100
            charger = 7
            Gmm = 2.5
        # -- 100kWh_11kW_30min
        elif scenario == '100kWh_11kW_30min':
            year_train = year_test - 1
            battery = 100
            charger = 11
            Gmm = 2.5
        # -- 100kWh_11kW_15min
        elif scenario == '100kWh_11kW_15min':
            year_train = year_test - 1
            battery = 100
            charger = 11
            Gmm = 5
        # --------------- RUN THE SIMULATION ------------------
        HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                             year_train, d_distance, uni, losses, regulation, robust, penalty,
                             kpen, py, plan_losses, save_result, sweep, stages,
                             d_time, bid_time)
        # --------------- EXTRACT RESULTS ------------------
        if HM.isnull().all().all():
            profits.loc[d_distance, (c_type, scenario)] = np.nan
        else:
            # find best tuple p and y
            ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
            p_star = HM.columns[ci]
            y_star = HM.index[ri]
            # --------------- EVALUATE ON TEST YEAR ------------------
            profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
            # Check for error message
            if type(profit_y0) == str:
                profits.loc[d_distance, (c_type, scenario)] = np.nan
            else:
                # assign cost to relevant dataframe
                profits.loc[d_distance, (c_type, scenario)] = round(profit_y0['Profit'].values[-1],2)
    # compute profit
    for c_type in Charger_types:
        for scenario in Scenarios:
            value_v2g.loc[d_distance, (c_type, scenario)] = round(profits.loc[d_distance, (c_type, scenario)] - profits.loc[d_distance, ('ref', scenario)],2)
# --------------------------------------------------
# save profits and value_v2g
fname = 'driving_distance.h5'
# - profits
profits.applymap(str).to_hdf(fname, key='profits', mode = 'w', format = 'table')
# - value_v2g
value_v2g.applymap(str).to_hdf(fname, key='value_v2g', mode = 'a', format = 'table')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
