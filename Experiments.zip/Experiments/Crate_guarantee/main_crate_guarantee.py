# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('---------- CRATE AND GUARANTEE SIMULATION ---------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Charger power in kW
Charger = 1+np.arange(20)
# Charger = [1]
# Battery size in kWh
Battery = [50, 75, 100]
# Battery = [50]
# EU regulation cycle in h
Gmms = [2.5, 5]
# Gmms = [2.5]

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Testing year in {2016, 2017, 2018, 2019}
year_test = 2019
year_train = year_test - 1
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.15]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Save results and verbose
save_result = True
verbose = False
# Base-case scenario
penalty = 'Exclusion'
uni = False
losses = True
regulation = True
robust = True
plan_losses = True

print('Common parameters:')
print('Year (test): '+str(year_test)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving time: '+str(d_time))
print('Uni: '+str(uni)+', Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
# loop over guarantees
for Gmm in Gmms:
    # regulation profits
    profits_reg = pd.DataFrame()
    # reference profits
    profits_ref = pd.DataFrame()
    # value_v2g
    value_v2g = pd.DataFrame()
    # loop over battery and charger sizes
    for battery in Battery:
        for charger in Charger:
            for regulation in [False, True]:
                # print scenario
                print('---------------------------------------------------')
                print('Gmm: '+str(Gmm)+', Battery: '+str(battery)+', Charger: '+str(charger)+', Regulation: '+str(regulation))
                print('---------------------------------------------------')
                # --------------- RUN THE SIMULATION ------------------
                HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year_train, d_distance, uni, losses, regulation, robust, penalty,
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)
                # --------------- EXTRACT RESULTS ------------------
                if HM.isnull().all().all():
                    profit = np.nan
                else:
                    # find best tuple p and y
                    ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
                    p_star = HM.columns[ci]
                    y_star = HM.index[ri]
                    # --------------- EVALUATE ON TEST YEAR ------------------
                    profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
                    profit = profit_y0['Profit'].values[-1]
                # assign profit to relevant dataframe
                if regulation:
                    profits_reg.loc[charger, battery] = profit
                else:
                    profits_ref.loc[charger, battery] = profit
            # compute profit
            value_v2g.loc[charger, battery] = profits_reg.loc[charger, battery] - profits_ref.loc[charger, battery]
    # --------------------------------------------------
    # save profits and value_v2g (Gmm is in minutes!)
    fname = 'crate_guarantee.h5'
    profits_reg.to_hdf(fname, key='profits_reg_'+str(round(60*Gmm)), mode = 'a')
    profits_ref.to_hdf(fname, key='profits_ref_'+str(round(60*Gmm)), mode = 'a')
    value_v2g.to_hdf(fname, key='value_v2g_'+str(round(60*Gmm)), mode = 'a')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
