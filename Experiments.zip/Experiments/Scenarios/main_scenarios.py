# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('--------------- SCENARIO SIMULATION ---------------')
print('---------------------------------------------------')

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Test year in {2016, 2017, 2018, 2019}
year_test = 2019
year_train = year_test - 1
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.15]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Save results and verbose
save_result = True
verbose = False

print('Common parameters:')
print('Year (test): '+str(year_test)+', Battery: '+str(battery)+', Charger: '+str(charger)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving time: '+str(d_time))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
Scenarios = ['base_case', 'no_losses', 'misspecified_losses', 'weaker_guarantee_and_exclusion', 'weaker_guarantee_and_penalty',
              'unidirectional']
Refs = ['ref_losses', 'ref_no_losses']
# Scenarios = ['base_case']
# Refs = ['ref_losses']              
# create results dataframe
profits = pd.DataFrame(columns = Scenarios+Refs)
value_v2g = pd.DataFrame(columns = Scenarios)

for scenario in Scenarios+Refs:
    print('---------------------------------------------------')
    print('Scenario: '+scenario)
    print('---------------------------------------------------')
    # case distinction
    # -- base case
    if scenario == 'base_case':         
        penalty = 'Exclusion'
        uni = False
        losses = True
        regulation = True
        robust = True
        plan_losses = True
    # -- no losses
    elif scenario == 'no_losses':
        penalty = 'Exclusion'
        uni = False
        losses = False
        regulation = True
        robust = True
        plan_losses = True
    # -- misspecified losses
    elif scenario == 'misspecified_losses':
        penalty = 'Exclusion'
        uni = False
        losses = True
        regulation = True
        robust = True
        plan_losses = False
    # -- weaker guarantee and exclusion
    elif scenario == 'weaker_guarantee_and_exclusion':
        penalty = 'Exclusion'
        uni = False
        losses = True
        regulation = True
        robust = False
        plan_losses = True
    # -- weaker guarantee and penalty
    elif scenario == 'weaker_guarantee_and_penalty':
        penalty = 'Fine'
        uni = False
        losses = True
        regulation = True
        robust = False
        plan_losses = True
    # -- unidirectional charging
    elif scenario == 'unidirectional':
        penalty = 'Exclusion'
        uni = True
        losses = True
        regulation = True
        robust = True
        plan_losses = True
    # -- ref losses
    elif scenario == 'ref_losses':
        penalty = 'Exclusion'
        uni = False
        losses = True
        regulation = False
        robust = True
        plan_losses = True
    # -- ref no losses
    elif scenario == 'ref_no_losses':
        penalty = 'Exclusion'
        uni = False
        losses = False
        regulation = False
        robust = True
        plan_losses = True

    # --------------- RUN THE SIMULATION ------------------
    HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year_train, d_distance, uni, losses, regulation, robust, penalty,
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)
    
    # --------------- EXTRACT RESULTS ------------------
    # find best tuple p and y
    ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
    p_star = HM.columns[ci]
    y_star = HM.index[ri]
    # --------------- EVALUATE ON TEST YEAR ------------------
    profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
    # read profits into dataframe
    profits[scenario] = profit_y0['Profit']
# --------------------------------------------------
# save results
fname = 'scenarios.h5'
# - profits
profits.to_hdf(fname, key='profits', mode = 'w')
# - value_v2g
for scenario in Scenarios:
    if scenario == 'no_losses':
        ref_name = 'ref_no_losses'
    else:
        ref_name = 'ref_losses'
    value_v2g[scenario] = profits[scenario] - profits[ref_name]
value_v2g.to_hdf(fname, key='value_v2g', mode = 'a')
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
