# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('---------- TEMPORAL EVOLUTION SIMULATION ---------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Testing years in {2016, 2017, 2018, 2019}
Years_test = [2016, 2017, 2018, 2019]
# Years_test = [2018, 2019]

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.15]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Base-case scenario
penalty = 'Exclusion'
uni = False
losses = True
regulation = True
robust = True
plan_losses = True
# Save results and verbose
save_result = True
verbose = False

print('Common parameters:')
print('Battery: '+str(battery)+', charger: '+str(charger)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving time: '+str(d_time))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
Scenarios = ['base']
Refs = ['ref']
# loop over years
for year_test in Years_test:
    year_train = year_test - 1
    # create result dataframes
    profits = pd.DataFrame(columns=['base', 'ref', 'value_v2g'])
    # loop over scenario
    for scenario in Scenarios+Refs:
        # -- base 
        if scenario == 'base':
            regulation = True
        # -- ref
        elif scenario == 'ref':
            regulation = False
        # print scenario
        print('---------------------------------------------------')
        print('Year (test): '+str(year_test)+', Scenario: '+scenario)
        print('---------------------------------------------------')
        # --------------- RUN THE SIMULATION ------------------
        HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year_train, d_distance, uni, losses, regulation, robust, penalty,
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)
        # --------------- EXTRACT RESULTS ------------------
        # find best tuple p and y
        ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
        p_star = HM.columns[ci]
        y_star = HM.index[ri]
        # --------------- EVALUATE ON TEST YEAR ------------------
        profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
        # read profits into dataframe
        profits[scenario] = profit_y0['Profit']
    # compute value_v2g
    profits['value_v2g'] = profits['base'] - profits['ref']
    # save profits and value_v2g
    fname = 'temporal_evolution.h5'
    profits.to_hdf(fname, key=str(int(year_test)), mode = 'a')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
