# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)
    
from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('---------- BID AT MIDNIGHT ---------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Testing years in {2016, 2017, 2018, 2019}
Years_test = [2016, 2017, 2018, 2019]
# Years_test = [2018]
Scenarios = ['noon', 'midnight', 'midnight_2stage']
# Scenarios = ['noon']

# --------------- COMMON PARAMETERS ---------------
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [50]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.15]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Base-case scenario
penalty = 'Exclusion'
regulation = True
uni = False
losses = True
robust = True
plan_losses = True
# Save results and verbose
save_result = True
verbose = False

print('Common parameters:')
print('Battery: '+str(battery)+', charger: '+str(charger)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh))
print('kpen: '+str(kpen)+', py: '+str(py)+', driving time: '+str(d_time))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
# create results dataframe
cnames = [['regulation', 'reference'], Scenarios]
profits = pd.DataFrame(columns = pd.MultiIndex.from_product(cnames))
value_v2g = pd.DataFrame(columns = Scenarios)
relative_gains = pd.DataFrame(index = Years_test) 

# loop over testing years
for year_test in Years_test:
    year_train = year_test - 1
    # loop through scenarios
    for (stype, scenario) in profits.columns:
        print('---------------------------------------------------')
        print('Year (test): '+str(year_test)+', scenario: '+str(scenario)+', '+str(stype))
        print('---------------------------------------------------')
        # case distinction: stype
        if stype == 'regulation':
            regulation = True
        elif stype == 'reference':
            regulation = False
        # case distinction: scenario
        # -- noon
        if scenario == 'noon':
            stages = 1
            bid_time = 'noon'       
        # -- midnight
        elif scenario == 'midnight':
            stages = 1
            bid_time = 'midnight'          
        # -- midnight 2stage
        elif scenario == 'midnight_2stage':
            stages = 2
            bid_time = 'midnight'
        # --------------- RUN THE SIMULATION ------------------
        HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                             year_train, d_distance, uni, losses, regulation, robust, penalty,
                             kpen, py, plan_losses, save_result, sweep, stages,
                             d_time, bid_time)
        # --------------- EXTRACT RESULTS ------------------
        # find best tuple p and y
        ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
        p_star = HM.columns[ci]
        y_star = HM.index[ri]
        # --------------- EVALUATE ON TEST YEAR ------------------
        profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
        # log results
        profits.loc[year_test, (stype, scenario)] = round(profit_y0['Profit'].values[-1], 2)
# --------------------------------------------------
# compute value_v2g and relative_gains
for year_test in Years_test:
    for scenario in Scenarios:
        value_v2g.loc[year_test, scenario] = round(profits.loc[year_test, ('regulation', scenario)] - profits.loc[year_test, ('reference', scenario)], 2)
        relative_gains.loc[year_test, scenario] = profits.loc[year_test, ('regulation', scenario)]
    relative_gains.loc[year_test, 'bid_at_midnight'] = round(relative_gains.loc[year_test, 'midnight'] - relative_gains.loc[year_test, 'noon'], 2)
    relative_gains.loc[year_test, 'two-stage'] = round(relative_gains.loc[year_test, 'midnight_2stage'] - relative_gains.loc[year_test, 'midnight'], 2)
# save results
fname = 'bid_at_midnight.h5'
# - profits
profits.applymap(str).to_hdf(fname, key = 'profits', mode = 'w', format = 'table')
# - value_v2g
value_v2g.applymap(str).to_hdf(fname, key = 'value_v2g', mode = 'a', format = 'table')
# - relative_gains
relative_gains.applymap(str).to_hdf(fname, key = 'relative_gains', mode = 'a', format = 'table')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
