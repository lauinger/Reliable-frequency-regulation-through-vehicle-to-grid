# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)
from my_functions import Simulation, Loop_Simulation

# --------------- PARAMETER LIST ------------------
# Planning stages
stages = 1
# Simulation year in {2015, 2016, 2017, 2018, 2019}
year = 2019
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Target state-of-charge in % of the battery size
y_star = 54
y_list = [50, 52, 54, 56, 58, 60]
# Deviation penalty in Euro/kWh
p_star = 0.15
p_list = [0.10, 0.15, 0.20, 0.25, 0.3]
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty for non-delivery of regulation power: either 'Exclusion' or 'Fine'
penalty = 'Fine'
# Penalty parameters for the calculation of the fine
kpen = 65 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'

# ------------ Boolean Variables
uni = False
losses = True
regulation = True
robust = False
plan_losses = True
# ------------ Save results and verbose
save_result = True
verbose = True
# ------------ Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'

#  ------------ Runs: either 'single' or 'multi'
runs = 'single'

# --------------- RUN THE SIMULATION ------------------
print('------------------------------------')
print('Year: '+str(year)+', Battery: '+str(battery)
      +', Charger: '+str(charger)+', Driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh))
print('Penalty: '+penalty+', kpen: '+str(kpen)+', py: '+str(py))
print('Uni: '+str(uni)+', Losses: '+str(losses)+', Regulation: '+str(regulation)
      +', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses)
      +', Stages: '+str(stages)+', Driving time: '+str(d_time)
      +', Bid time: '+str(bid_time))
print('------------------------------------')

# begin time measurement
start = time.time()

if runs == 'single':
    print('p_star: '+str(p_star)+', y_star: '+str(y_star))
    print('------------------------------------')
    profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
if runs == 'multi':
    print('p_list: '+str(p_list))
    print('y_list: '+str(y_list))
    print('Sweep: '+sweep)
    print('------------------------------------')
    HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year, d_distance, uni, losses, regulation, robust, penalty, 
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)

# end time measurement
end = time.time()
print('------------------------------------')
# ~ print('Execution time : '+str(round((end - start)/60))+'min')
print('Execution time : '+str(round((end - start)))+'s')
print('------------------------------------')
