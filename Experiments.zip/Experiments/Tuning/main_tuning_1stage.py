# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import pandas as pd
import numpy as np
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)
from my_functions import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('---------- PARAMETER TUNING 1STAGE ---------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Training years in {2015, 2016, 2017, 2018, 2019}
Years = [2015, 2016, 2017, 2018, 2019]
# Years = [2015]

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [50]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.10]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Penalty parameters for the calculation of the fine in case of non-delivery
kpen = 5 # Penalty factor (-)
py = 0.75 # Reserve price (Euro/kWh)
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Base-case scenario
penalty = 'Exclusion'
uni = False
losses = True
regulation = True
robust = True
plan_losses = True
# Save results and verbose
save_result = True
verbose = False

print('Common parameters:')
print('Battery: '+str(battery)+', charger: '+str(charger)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('kpen: '+str(kpen)+', py: '+str(py)+', Stages: '+str(stages)+', driving time: '+str(d_time))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- CALCULATIONS ---------------

# create results dataframe
cnames = [['anticipative', 'non-anticipative'], ['p_star', 'y_star', 'profit']]
df = pd.DataFrame(columns = pd.MultiIndex.from_product(cnames))

# loop over training years
for year_train in Years:
    # print simulation
    print('---------------------------------------------------')
    print('Year (train): '+str(year_train))
    print('---------------------------------------------------')
    # --------------- RUN THE SIMULATION ------------------
    HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year_train, d_distance, uni, losses, regulation, robust, penalty,
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)
    # --------------- EXTRACT RESULTS ------------------
    # find best tuple p and y
    ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
    p_star = HM.columns[ci]
    y_star = HM.index[ri]
    # log them as being the best tuple
    df.loc[year_train, ('anticipative', ['p_star', 'y_star', 'profit'])] = [p_star, y_star, round(HM.loc[y_star, p_star],2)]
    if year_train < 2019:
        year_test = year_train + 1
        # --------------- EVALUATE ON TEST YEAR ------------------
        profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
        # read profit
        profit = profit_y0['Profit'].values[-1]
        # log results
        df.loc[year_test, ('non-anticipative', ['p_star', 'y_star', 'profit'])] = [p_star, y_star, round(profit,2)]
# --------------------------------------------------
# compute regret
df['regret'] = df[('anticipative', 'profit')] - df[('non-anticipative', 'profit')]
# save results
fname = 'tuning_1stage.h5'
df.applymap(str).to_hdf(fname, key='df', mode = 'w', format = 'table')
# --------------------------------------------------
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
