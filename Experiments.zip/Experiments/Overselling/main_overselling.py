# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:32:44 2020

@author: lauinger
"""
import numpy as np
import pandas as pd
import time
import os, sys
p = os.path.abspath('..')
if p not in sys.path:
    sys.path.append(p)

from my_functions import Simulation, Loop_Simulation
# from my_functions_debug import Simulation, Loop_Simulation

print('---------------------------------------------------')
print('------------- OVERSELLING SIMULATION --------------')
print('---------------------------------------------------')

# --------------- VARIABLE PARAMETERS ---------------
# Penalty parameters for the calculation of the fine in case of non-delivery
# kpen = 5 # Penalty factor (-)
# py = 0.75 # Reserve price (Euro/kWh)
# penalty = Exclusion

# --------------- COMMON PARAMETERS ---------------
# Planning stages
stages = 1
# Testing year in {2016, 2017, 2018, 2019}
year_test = 2019
year_train = year_test - 1
# Target state-of-charge in % of the battery size
y_list = [50, 52, 54, 56, 58, 60]
# y_list = [54]
# Deviation penalty in Euro/kWh
p_list = [0.10, 0.125, 0.15, 0.175, 0.20, 0.225, 0.25, 0.275, 0.30]
# p_list = [0.15]
# Parameter sweep: either 'nested' or 'sequential'
sweep = 'nested'
# Runs: either 'single' or 'multi'
runs = 'multi'
# Battery size in kWh
battery = 50
# Charger power in kW
charger = 7
# Driving distance (1 corresponds to 10,000 km)
d_distance = 1
# Driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
d_time = 'fixed'
# EU activation period in h
gmm = 0.5
# EU regulation cycle in h: either 2.5 or 5
Gmm = 2.5
# Reduced activation period in h
gmmh = 0.5
# Prolonged regulation cycle in h
Gmmh = 24
# Bid Time: either 'noon' or 'midnight'
bid_time = 'noon'
# Save results and verbose
save_result = True
verbose = False
# Base-case non-robust scenario
losses = True
uni = False
regulation = True
robust = False
plan_losses = True

print('Common parameters:')
print('Year (test): '+str(year_test)+', Battery: '+str(battery)+', Charger: '+str(charger)+', driving distance: '+str(d_distance))
print('gmm: '+str(gmm)+', Gmm: '+str(Gmm)+', gmmh: '+str(gmmh)+', Gmmh: '+str(Gmmh)+', bid time: '+str(bid_time))
print('Stages: '+str(stages)+', driving time: '+str(d_time))
print('Losses: '+str(losses)+', Regulation: '+str(regulation)+', Robust: '+str(robust)+', Uni: '+str(uni)+', Plan losses: '+ str(plan_losses))
print('p_list: '+str(p_list))
print('y_list: '+str(y_list))
print('Sweep: '+sweep)

# begin time measurement
start = time.time()

# --------------- SCENARIOS ---------------
Scenarios = ['exclusion', 'k5_py075', 'k10_py075', 'k65_py075','k70_py075','k100_py075', 'k5_py750', 'k5_py7500']
# Scenarios = ['exclusion']
Refs = ['ref']
# create results dataframe
profits = pd.DataFrame(columns = Scenarios+Refs)
value_v2g = pd.DataFrame(columns = Scenarios)
exclusion = pd.DataFrame(columns = Scenarios)
fine = pd.DataFrame(columns = Scenarios)
fast_charger = pd.DataFrame(columns = Scenarios)

for scenario in Scenarios+Refs:
    print('---------------------------------------------------')
    print('Scenario: '+scenario)
    print('---------------------------------------------------')
    # case distinction
    # -- exclusion
    if scenario == 'exclusion':         
        regulation = True
        penalty = 'Exclusion'
        kpen = 5
        py = 0.75
    # -- k5_py075
    elif scenario == 'k5_py075':
        regulation = True
        penalty = 'Fine'
        kpen = 5
        py = 0.75
    # -- k10_py075
    elif scenario == 'k10_py075':
        regulation = True
        penalty = 'Fine'
        kpen = 10
        py = 0.75
    # -- k65_py075
    elif scenario == 'k65_py075':
        regulation = True
        penalty = 'Fine'
        kpen = 65
        py = 0.75
    # -- k70_py075
    elif scenario == 'k70_py075':
        regulation = True
        penalty = 'Fine'
        kpen = 70
        py = 0.75
    # -- k100_py075
    elif scenario == 'k100_py075':
        regulation = True
        penalty = 'Fine'
        kpen = 100
        py = 0.75
    # -- k5_py750
    elif scenario == 'k5_py750':
        regulation = True
        penalty = 'Fine'
        kpen = 5
        py = 7.5
    # -- k5_py7500
    elif scenario == 'k5_py7500':
        regulation = True
        penalty = 'Fine'
        kpen = 5
        py = 75
    # -- ref
    elif scenario == 'ref':
        regulation = False
        penalty = 'Exclusion'
        kpen = 5
        py = 0.75

    # --------------- RUN THE SIMULATION ------------------
    HM = Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                         year_train, d_distance, uni, losses, regulation, robust, penalty,
                         kpen, py, plan_losses, save_result, sweep, stages,
                         d_time, bid_time)
    
    # --------------- EXTRACT RESULTS ------------------
    # find best tuple p and y
    ri, ci = np.unravel_index(np.nanargmax(HM.values), HM.shape)
    p_star = HM.columns[ci]
    y_star = HM.index[ri]
    # --------------- EVALUATE ON TEST YEAR ------------------
    profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                           y_star, p_star, year_test, d_distance, uni, losses,
                           regulation, robust, penalty, kpen, py,
                           plan_losses, save_result, verbose, stages,
                           d_time, bid_time)
    # read profits into dataframe
    profits[scenario] = profit_y0['Profit']
    exclusion[scenario] = profit_y0['exclusion']
    fine[scenario] = profit_y0['fine']
    fast_charger[scenario] = profit_y0['fast_charger']
# --------------------------------------------------
# save profits
fname = 'overselling.h5'
profits.to_hdf(fname, key='profits', mode = 'w')
exclusion.to_hdf(fname, key='exclusion', mode = 'a')
fine.to_hdf(fname, key='fine', mode = 'a')
fast_charger.to_hdf(fname, key='fast_charger', mode = 'a')
# compute value_v2g
for scenario in Scenarios:
    value_v2g[scenario] = profits[scenario] - profits['ref']
# save value_v2g
value_v2g.to_hdf(fname, key='value_v2g', mode = 'a')
# end time measurement
end = time.time()
print('------------------------------------')
print('Execution time : '+str(round((end - start)/3600,2))+'h')
print('------------------------------------')
