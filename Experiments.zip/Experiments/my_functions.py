# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 16:30:57 2020

@author: lauinger
"""

from gurobipy import *
import pandas as pd
import numpy as np
import datetime as datetime

############################################################################

def Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                    year, d_distance = 1, uni = False, losses = True, regulation = True,
                    robust = True, penalty = 'Exclusion', kpen = 5, py = 0.75,
                    plan_losses = True, save_result = False, sweep = 'nested',
                    stages = 1, d_time = 'fixed', bid_time = 'noon'):
    """
    Loop_Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_list, p_list,
                    year, d_distance = 1, uni = False, losses = True, regulation = True,
                    robust = True, penalty = 'Exclusion', kpen = 5, py = 0.75,
                    plan_losses = True, save_result = False, sweep = 'nested',
                    stages = 1, d_time = 'fixed', bid_time = 'noon')

    Computes the cumulative profit of vehicle-to-grid for each combination of
    the elements in the lists p_star_list and y_star_list for the 'year'.

    Return an error message and np.nan if a combination causes an error.

    INPUTS:
        charger:    charger power (kW)
        battery:    battery capacity (kWh)
        gmm:        activation period (h)
        Gmm:        regulation cycle (h)
        gmmh:       reduced activation period (h)
        Gmmh:       reduced regulation cycle (h)
        y_list:     list of state-of-charge target (%)
        p_list:     list of deviation penalties (EUR/kWh)
        year:       element of {2015, 2016, 2017, 2018, 2019}
        d_distance: multiplier for yearly energy consumption for driving -
                        default is 2,000 kWh/yr or 10,000 km/yr
        uni:        uni- or bidirectional charger
        losses:     with or without conversion losses
        regulation: active or not active on the regulation market
        robust:     constraint protection for gmm and Gmm if true,
                        and for gmmh and Gmmh otherwise
        penalty:    penalty for non-delivery of promised regulation power,
                        either "Exclusion" or "Fine"
        kpen:       penalty factor set by the TSO--multiplies the availabitity price
        py:         price for instantaneous charging (EUR/kWh)
        plan_losses:does the planning problem consider losses?
        save_result:whether or not to save the results in a .h5 file
        sweep:      'nested' or 'sequential' for-loops
        stages:     planning stages either 1 or 2
        d_time:     driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
        bid_time:   either 'noon' or 'midnight' on the previous day

    OUTPUTS:
        HM: dataframe with the cumulative profit of vehicle-to-grid for each
        combination of the elements in the lists p_star_list and y_star_list
        for the 'year'.

        This dataframe is saved under the following name:
        HM_'+str(year)+'_'+str(charger)+'kW_'+str(battery)+'kWh_'+str(gmm)+'gmm_'
            +str(Gmm)+'Gmm'_+str(d_distance)+'d_distance_'+str(penalty)+'_'+str(kpen)+'kpen_'
            +str(py)+'py_'+str(uni)+'_uni_'+str(losses)+'_losses_'+str(regulation)
            +'_regulation_'+str(robust)+'_robust_'+str(plan_losses)+'_plan_losses_'
            +str(stages)+'_stages_'+str(d_time)+'_d_time_'+str(bid_time)+'_bid_time_'+str(sweep)+'.h5'
    """
    # Declare the results dataframe
    HM = pd.DataFrame(np.nan, index=y_list, columns=p_list)
    # Set-Up a progress counter
    progress = 1
    # nested search
    if sweep == 'nested':
        # Sweep over p_star
        for p_star in p_list:
            # Sweep over y_star
            for y_star in y_list:
                # Run the simulation
                profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                                       y_star, p_star, year, d_distance, uni, losses,
                                       regulation, robust, penalty, kpen, py,
                                       plan_losses, save_result, verbose=False,
                                       stages = stages, d_time = d_time, bid_time = bid_time)
                # Check for error message
                if type(profit_y0) == str:
                    print(profit_y0)
                else:
                    HM.loc[y_star, p_star] = profit_y0['Profit'].values[-1]
                # Show profit and progress message
                print('y_star: '+str(y_star)+', p_star: '+str(p_star)
                       +', profit: '+str(round(HM.loc[y_star, p_star],2)))
                print('Progress ', int(100*progress/(len(y_list)*len(p_list))))
                print('------------------------------------')
                progress = progress + 1
    # sequential search
    elif sweep == 'sequential':
        # start with the highest SOC, last element in the list
        y_star = y_list[-1]
        # Sweep over p_star
        for p_star in p_list:
            # Run the simulation
            profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                                   y_star, p_star, year, d_distance, uni, losses,
                                   regulation, robust, penalty, kpen, py,
                                   plan_losses, save_result, verbose=False,
                                   stages = stages, d_time = d_time, bid_time = bid_time)
            # Check for error message
            if type(profit_y0) == str:
                print(profit_y0)
            else:
                HM.loc[y_star, p_star] = profit_y0['Profit'].values[-1]
            # Show profit and progress message
            print('y_star: '+str(y_star)+', p_star: '+str(p_star)
                   +', profit: '+str(round(HM.loc[y_star, p_star],2)))
            print('Progress ', int(100*progress/(len(y_list) + len(p_list) - 1)))
            print('------------------------------------')
            progress = progress + 1
        # identify the best p_star
        p_star = HM.loc[y_star].idxmax()
        # Sweep over y_star
        for y_star in y_list[:-1]:
            # Run the simulation
            profit_y0 = Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh,
                                   y_star, p_star, year, d_distance, uni, losses,
                                   regulation, robust, penalty, kpen, py,
                                   plan_losses, save_result, verbose=False,
                                   stages = stages, d_time = d_time, bid_time = bid_time)
            # Check for error message
            if type(profit_y0) == str:
                print(profit_y0)
            else:
                HM.loc[y_star, p_star] = profit_y0['Profit'].values[-1]
            # Show profit and progress message
            print('y_star: '+str(y_star)+', p_star: '+str(p_star)
                   +', profit: '+str(round(HM.loc[y_star, p_star],2)))
            print('Progress ', int(100*progress/(len(y_list) + len(p_list) - 1)))
            print('------------------------------------')
            progress = progress + 1
    # misspecified sweep
    else:
        print('ERROR: sweep must be either \'nested\' or \'sequential\'.')
    # Save the heatmap
    if save_result:
        HM.to_hdf('Results/HM_'+str(year)+'_'+str(charger)+'kW_'+str(battery)+'kWh_'
                  +str(gmm)+'gmm_'+str(Gmm)+'Gmm_'+str(d_distance)+'d_distance_'
                  +str(penalty)+'_'+str(kpen)+'kpen_'+str(py)+'py_'
                  +str(uni)+'_uni_'+str(losses)+'_losses_'
                  +str(regulation)+'_regulation_'+str(robust)+'_robust_'
                  +str(plan_losses)+'_plan_losses_'
                  +str(stages)+'_stages_'+str(d_time)+'_d_time_'+str(bid_time)+'_bid_time_'
                  +str(sweep)+'.h5', key='HM')
    # Return the results
    return HM

############################################################################

def Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_star, p_star, year,\
               d_distance = 1, uni = False, losses = True, regulation = True,\
               robust = True, penalty = 'Exclusion', kpen = 5, py = 0.75,\
               plan_losses = True, save_result = False, verbose = True,\
               stages = 1, d_time = 'fixed', bid_time = 'noon'):
    """
    Simulation(charger, battery, gmm, Gmm, gmmh, Gmmh, y_star, p_star, year,\
               d_distance = 1, uni = False, losses = True, regulation = True,\
               robust = True, penalty = 'Exclusion', kpen = 5, py = 7.5,\
               plan_losses = True, save_result = False, verbose = True,\
               stages = 1, d_time = 'fixed', bid_time = 'noon')

    Computes the state-of-charge and cumulative profit at the end of each
    day of the 'year'.

    INPUTS:
        charger:    charger power (kW)
        battery:    battery capacity (kWh)
        gmm:        activation period (h)
        Gmm:        regulation cycle (h)
        gmmh:       reduced activation period (h)
        Gmmh:       reduced regulation cycle (h)
        y_star:     state-of-charge target (%)
        p_star:     deviation penalty (EUR/kWh)
        year:       element of {2015, 2016, 2017, 2018, 2019}
        d_distance: multiplier for yearly energy consumption for driving -
                        default is 2,000 kWh/yr or 10,000 km/yr
        uni:        uni- or bidirectional charger
        losses:     with or without conversion losses
        regulation: active or not active on the regulation market
        robust:     constraint protection for gmm and Gmm if true,
                        and for gmmh and Gmmh otherwise
        penalty:    penalty for non-delivery of promised regulation power,
                        either "Exclusion" or "Fine"
        kpen:       penalty factor set by the TSO--multiplies the availabitity price
        py:         price for instantaneous charging (EUR/kWh)
        plan_losses:does the planning problem consider losses?
        save_result:whether or not to save the results in a .h5 file
        verbose:    whether or not to show comments
        stages:     planning stages either 1 or 2
        d_time:     driving times: either 'fixed' or in {0, 1, ..., 22}, which represents the hours of driving per day
        bid_time:   either 'noon' or 'midnight' on the previous day

    OUTPUTS:
        profit_y0:  dataframe with the state-of-charge and the cumulative profit
                    at the end of each day as columns. Return an error message
                    if the problem is infeasible.

        This dataframe is saved under the following name:
        str(year)+'_'+str(y_star*100/battery)+'y_'+str(p_star)+'p_'
            +str(charger)+'kW_'+str(battery)+'kWh_'+str(gmm)+'gmm_'+str(Gmm)+'Gmm_'+
            +str(d_distance)+'d_distance_'+str(penalty)+'_'+str(kpen)+'kpen_'+str(py)+'py_'
            +str(uni)+'_uni_'+str(losses)+'_losses_'+str(regulation)+'_regulation_'
            +str(robust)+'_robust_'+str(plan_losses)+'_plan_losses_'
            +str(stages)+'_stages_'+str(d_time)+'_d_time_'+str(bid_time)+'_bid_time.h5'
    """
    # -------------------- Prepare simulation parameters -------------------
    # Load data
    pr = pd.read_hdf('../_data/pr.h5')
    pa = pd.read_hdf('../_data/pa.h5')
    pb = pd.read_hdf('../_data/pb.h5')
    d = pd.read_hdf('../_data/ds_driving_time.h5', key = 'd')
    s = pd.read_hdf('../_data/ds_driving_time.h5', key = 's')
    # Account for driving style
    ds = pd.DataFrame()
    d_time = str(d_time)
    ds['d'] = d[d_time]
    ds['s'] = s[d_time]
    # Load the frequency deviation signal depending on the EU activation period
    if Gmm == 2.5:
        delta = pd.read_hdf('../_data/delta_Gmm_2pt5hours.h5')
    elif Gmm == 5:
        delta = pd.read_hdf('../_data/delta_Gmm_5hours.h5')
    else:
        if verbose:
            print('ERROR: Gmm must be either 2.5 or 5')
        return 'ERROR: Gmm must be either 2.5 or 5'

    # Account for difference in driving
    ds['d'] = d_distance*ds['d']

    # Time Discretization, Planning Horizon Length
    dt = 0.5            # hours - planning time resolution
    ddt = 10            # seconds - simulation time resolution
    K = int(24/dt)      # length of the planning horizon

    # Minimum frequency deviation resolution
    delta_res = 10 / 200 # 10 out of 200 mHz

    # Battery Characteristics (kWh)
    y_max = 0.8*battery
    y_min = 0.2*battery

    # Charger efficiencies
    if losses:
        nc = 0.85
        nd = 0.85
    else:
        nc = 1
        nd = 1

    dn = 1/nd-nc

    # save a copy of the original gamma for the name of the results datafile
    gmm_org = gmm
    Gmm_org = Gmm

    # Planned efficiencies
    if plan_losses:
        nc_plan = nc
        nd_plan = nd
    else:
        nc_plan = 1
        nd_plan = 1
    dn_plan = 1/nd_plan - nc_plan

    # Robustness
    if robust:
        gmm = gmm
        Gmm = Gmm
    else:
        gmm = gmmh
        Gmm = Gmmh

    # Utility Price
    uprice = "Tempo"

    # Convert target state-of-charge from % to kWh
    y_star = y_star*battery/100

    # define 1stage value function
    phi_1stage = pd.DataFrame({'slope': [p_star, -p_star], 'intercept': [-p_star*y_star, p_star*y_star]})

    # Select test days
    if year == 2015:
        T = pd.date_range('01-01-2015 00:00:00', '12-31-2015', freq='D')
        T_30min = pd.date_range('01-01-2015 00:00:00', '12-31-2015 23:30:00', freq='30min')
    elif year == 2016:
        T = pd.date_range('01-01-2016 00:00:00', '12-31-2016', freq='D')
        T_30min = pd.date_range('01-01-2016 00:00:00', '12-31-2016 23:30:00', freq='30min')
    elif year == 2017:
        T = pd.date_range('01-01-2017 00:00:00', '12-31-2017', freq='D')
        T_30min = pd.date_range('01-01-2017 00:00:00', '12-31-2017 23:30:00', freq='30min')
    elif year == 2018:
        T = pd.date_range('01-01-2018 00:00:00', '12-31-2018', freq='D')
        T_30min = pd.date_range('01-01-2018 00:00:00', '12-31-2018 23:30:00', freq='30min')
    elif year == 2019:
        T = pd.date_range('01-01-2019 00:00:00', '12-31-2019', freq='D')
        T_30min = pd.date_range('01-01-2019 00:00:00', '12-31-2019 23:30:00', freq='30min')

    # Set-up profit counter and bidding market
    profit = 0
    # Declare result dataframe
    profit_y0 = pd.DataFrame(np.nan, index=T, columns = ['Profit', 'y0',
                                'y0_min', 'y0_hat_min', 'y0_hat_max', 'y0_max',
                                'exclusion', 'fine', 'fast_charger'])
    dec_soc = pd.DataFrame(np.nan, index=T_30min, columns = ['xb', 'xr', 'd', 'y'])

    # initialize state-of-charge estimates
    y0 = y_star
    y0_min = y_star; y0_max = y_star; y0_hat_min = y_star; y0_hat_max = y_star
    # y0_min = max(y_min, y_star - 0.1*battery)
    # y0_max = min(y_max, y_star + 0.1*battery)
    # y0_hat_min = min(y_min, y_star - 0.05*battery)
    # y0_hat_max = max(y_max, y_star + 0.05*battery)
    # initialize market participation and feasibility
    infeasible = False
    if regulation:
        market = 'regulation'
    else:
        market = 'utility'

    # -------------------- Run the simulation ------------------------------
    for t_day in T:
        # For debugging
        # ~ if t_day == T[1]:
            # ~ return profit_y0
        t = pd.date_range(t_day, periods = K, freq='30min')
        # Charger Characteristics (kW)
        yc_max = charger*ds.loc[t,'s']          # charging
        if uni:
            yd_max = 0*ds.loc[t,'s']            # discharging
        else:
            yd_max = charger*ds.loc[t,'s']      # discharging

        # Assign initial state-of-charge to results dataframe
        # ~ profit_y0['y0'][t_day] = y0

        # step 1: compute value function
        # 1 planning stage
        if stages == 1:
            phi = phi_1stage
        if stages == 2:
        # 2 planning stages
            if t_day == T[-1]:
                phi = phi_1stage
            else:
                # look one day ahead
                t_day_next = t_day + pd.Timedelta(days = 1)
                t_vf = pd.date_range(t_day_next, periods = K, freq='30min')
                # charger Characteristics for the next day(kW)
                yc_max_vf = charger*ds.loc[t_vf,'s']          # charging
                if uni:
                    yd_max_vf = 0*ds.loc[t_vf,'s']            # discharging
                else:
                    yd_max_vf = charger*ds.loc[t_vf,'s']      # discharging
                # compute phi
                phi, pts, feasible = calc_phi(pr.loc[t_vf,:], pb.loc[t_vf, uprice],\
                                           ds.d[t_vf], K, y_max, y_min, yc_max_vf, yd_max_vf, phi_1stage, \
                                           nc_plan, nd_plan, dn_plan, dt, gmm, Gmm, gmmh, Gmmh, \
                                           N = 15, tol = 0.01, n_dig = 6, market = market, verbose = False)
                # check for feasibility
                if not feasible:
                    if verbose:
                        print('ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.')
                        print('Abort simulation.')
                    return 'ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.'

        # step 2: optimize
        if market == 'regulation':
            res_bid = Reg(pr=pr.loc[t,:],pb=pb.loc[t,uprice], d=ds.d[t], K=K,\
                          y_max = y_max,y_min=y_min,yc_max=yc_max,yd_max=yd_max,\
                          y0_min = y0_min, y0_max = y0_max,\
                          y0_hat_min = y0_hat_min, y0_hat_max = y0_hat_max,\
                          phi = phi,\
                          nc=nc_plan,nd=nd_plan, dn=dn_plan, dt=dt,\
                          gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh)
            # Check whether the problem is infeasible:
            if res_bid['profit'] == 'Infeasible':
                if verbose:
                    print('ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.')
                    print('Abort simulation.')
                return 'ERROR: Infeasible bidding problem. Check whether \'ds.d\' is too high.'

            # Calculate new state-of-charge if the bidding problem is feasible
            else:
                tt = pd.date_range(t_day, periods = K*dt/ddt*3600, freq='10s')
                res_soc = Calc_y0(t=t, tt=tt, dt=dt, ddt=ddt, d = ds.d[t], \
                                   xr=res_bid['xr'], xb=res_bid['xb'],\
                                   y0=y0, delta=delta.loc[tt,:], delta_res = delta_res,\
                                   K=K, nc = nc, nd = nd, dn = dn,\
                                   nc_plan = nc_plan, nd_plan = nd_plan, dn_plan = dn_plan,\
                                   gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh,\
                                   y_max = y_max, y_min = y_min, bid_time = bid_time)
                # For degugging
#                print(res_soc['y0'])
                if verbose:
                    print(str(t_day.date()) +' ymin : ' +str(round(res_soc['ymin'],2))+'kWh')
                    print(str(t_day.date()) +' ymax : ' +str(round(res_soc['ymax'],2))+'kWh')

                # Update profit
                profit = profit + res_bid['profit']

                # Calculate the fine for missing regulation power
                fine = dt * sum(res_soc['xr_m'] * kpen * pa['pa'].loc[t] \
                                   + res_soc['d_m'] * py)

                if fine > 0:
                    # Account for the penalty mechanisms
                    if penalty == 'Exclusion':
                        # Switch to the utility market
                        if verbose:
                            print('++++++++++++++++++++++++++++++++++++++++++++++++++++')
                            print(str(t_day.date()) +' Exclusion from regulation market')
                            print('++++++++++++++++++++++++++++++++++++++++++++++++++++')
                        market = 'utility'
                        profit_y0.loc[t_day, 'exclusion'] = 1

                    elif penalty == 'Fine':
                        if verbose:
                            print(str(t_day.date()) + ' Fine : ' + str(round(fine,2)) + 'EUR')
                        # Update profit
                        profit = profit - fine
                        profit_y0.loc[t_day, 'fine'] = dt * sum(res_soc['xr_m'] * kpen * pa['pa'].loc[t])
                        profit_y0.loc[t_day, 'fast_charger'] = dt * sum(res_soc['d_m'] * py)
                    else:
                        if verbose:
                            print('ERROR: \'penalty\' must be either \'Exclusion\' or \'Fine\'')
                            print('Abort simulation.')
                        return 'ERROR: \'penalty\' must be either \'Exclusion\' or \'Fine\''

                else:
                    profit_y0.loc[t_day, ['exclusion', 'fine', 'fast_charger']] = [0, 0, 0]                                          
                # Assign new state-of-charge
                y0_min = res_soc['y0_min']
                y0_max = res_soc['y0_max']
                y0_hat_min = res_soc['y0_hat_min']
                y0_hat_max = res_soc['y0_hat_max']
                y0 = res_soc['y0']
                # For debugging
#                print('y0 : ' + str(y0))
#                print('y0_min : ' + str(y0_min))
#                print('y0_max : ' + str(y0_max))
#                print('y0_hat_min : ' + str(y0_hat_min))
#                print('y0_hat_max : ' + str(y0_hat_max))

        if market == 'utility':
            res_utl = Utl(pb=pb.loc[t,uprice], d = ds.d[t], K = K,\
                                  y_max = y_max, y_min = y_min,\
                                  yc_max = yc_max, y0 = y0, nc = nc,\
                                  dt = dt, phi = phi)
            if res_utl['profit'] == 'Infeasible':
                if verbose:
                    print('ERROR: Infeasible utility purchases. Check whether \'ds.d\' is too high.')
                    print('Abort simulation.')
                return 'ERROR: Infeasible utility purchases. Check whether \'ds.d\' is too high.'
            else:
                profit = profit + res_utl['profit']
                y0 = res_utl['y0']
                y0_min = y0; y0_hat_min = y0; y0_hat_max = y0; y0_max = y0
        # assign resulting profit and state-of-charge to results
        # ~ profit_y0['Profit'][t_day] = profit
        # ~ profit_y0['y0'][t_day] = y0
        profit_y0.loc[t_day, ['Profit', 'y0', 'y0_min', 'y0_hat_min', 'y0_hat_max', 'y0_max']] = [profit, y0, y0_min, y0_hat_min,
                                    y0_hat_max, y0_max]
        # market bids, driving patterns, and state-of-charge throughout the day
        dec_soc.loc[t, 'd'] = ds.d[t]
        if market == 'regulation':
            dec_soc.loc[t, 'xb'] = res_bid['xb']
            dec_soc.loc[t, 'xr'] = res_bid['xr']
            dec_soc.loc[t, 'y'] = res_soc['y']
        elif market == 'utility':
            dec_soc.loc[t, 'xb'] = res_utl['xb']
            dec_soc.loc[t, 'y'] = res_utl['y']

        # Progress statement
        if verbose:
            print(str(t_day.date()) + ' Profit: ' + str(round(profit,2)) + 'EUR')
            print(str(t_day.date()) + ' SOC: ' + str(round(y0,2)) + 'kWh')
            print('----------------------------------------------------')

    # -------------------- Save the results --------------------------------
    # runfile name
    fname = 'Results/'+str(year)+'_'\
                     +str(round(y_star*100/battery))+'y_'+str(p_star)+'p_'\
                     +str(charger)+'kW_'+str(battery)+'kWh_'\
                     +str(gmm_org)+'gmm_'+str(Gmm_org)+'Gmm_'+str(d_distance)+'d_distance_'\
                     +str(penalty)+'_'+str(kpen)+'kpen_'+str(py)+'py_'\
                     +str(uni)+'_uni_'+str(losses)+'_losses_'\
                     +str(regulation)+'_regulation_'\
                     +str(robust)+'_robust_'\
                     +str(plan_losses)+'_plan_losses_'\
                     +str(stages)+'_stages_'\
                     +str(d_time)+'_d_time_'\
                     +str(bid_time)+'_bid_time.h5'
    # save results
    profit_y0.to_hdf(fname, key='profit_y0')
    dec_soc.to_hdf(fname, key='dec_soc')
    # Return the results
    return profit_y0

############################################################################

def Calc_y0(t, tt, dt, ddt, d, xr, xb, y0, delta, delta_res, K, nc, nd, dn,\
            nc_plan, nd_plan, dn_plan, gmm, Gmm, gmmh, Gmmh, y_max, y_min, bid_time):
    """
    Returns several measures of the state-of-charge at the end of the current day:
        'y0':         the true state-of-charge (kWh)
        'y0_min':     a conservative lower bound (kWh)
        'y0_max':     a conservative upper bound (kWh)
        'y0_hat_min': a less conservative lower bound (kWh)
        'y0_hat_max': a less conservative upper bound (kWh)
    In addition, it returns:
        'ymin':       the true minimum of the state-of-charge during the current day (kWh)
        'ymax':       the true maximum of the state-of-charge during the current day (kWh)
        'xr_m':       the amount of missing regulation power during each time interval (kW)
        'd_m':        the amount of missing power for driving during each time interval (kW)
    """

    # convert ddt into hours
    ddt = ddt/3600

    # --------------------- Calculate the true state-of-charge -------------
    # build a dataframe of the market decisions for the current day
    df = pd.DataFrame({'xb': xb, 'xr':xr}, index=t)
    df['d'] = d[tt]
    # resample the dataframe from a 30min to a 10s resolution
    df = df.reindex(index = tt, method='ffill')
    df['delta'] = delta
    # add columns for the power missing for frequency regulation and for driving
    df['xr_m'] = 0   # power missing for frequency regulation
    df['d_m'] = 0    # power missing for driving
    # account for the lower and the upper bound on the battery state-of-charge
    df['y'] = np.nan # state-of-charge

    # --------------------- Non-robust case: missing power is possible
    if (gmm/Gmm == gmmh/Gmmh) | (nc != nc_plan) | (nd != nd_plan):
        # calculate soc and penalties iteratively
        for idx in df.index:
            # calculate state-of-charge at idx-1
            if idx == df.index[0]:
                y = y0
            else:
                y = df.y[idx - idx.freq]
            # case distinction: parking or driving
            if df.d[idx] == 0:  # parking
                # nominal power consumption
                x = df.xb[idx] + df.delta[idx] * df.xr[idx]
                # real power consumption when charging (note that the vehicle
                # ... is either charging or discharging but never both simultaneously)
                # ... the factor 1.001 is for numerical stability
                xhat = min( x, (1.001*y_max - y)/(nc * ddt) )
                # real power consumption when discharging
                # ... the factor 0.999 is for numerical stability
                xhat = max( xhat, nd*(0.999*y_min - y)/ddt )
                # missing reserve power
                df.loc[idx, 'xr_m'] = abs(x-xhat) / max(abs(df.delta[idx]), delta_res)
                # update y
                df.loc[idx, 'y'] = y + min(nc*xhat, xhat/nd) * ddt
            else: # driving
                # real power available for driving
                # the factor 0.999 is for numerical stability
                dhat = min( df.d[idx], (y - 0.999*y_min)/ddt )
                # missing power for driving
                df.loc[idx, 'd_m'] = df.d[idx] - dhat
                # update y
                df.loc[idx, 'y'] = y - dhat * ddt
    # --------------------- Robust case: missing power is impossible
    else:
        # calculate nominal charging
        yp = df['xb'] + df['delta'] * df['xr']
        # ... and discharging rates
        ym = - (df['xb'] + df['delta'] * df['xr'])
        # impose their non-negativity
        yp[yp < 0] = 0
        ym[ym < 0] = 0
        # update the state-of-charge accordingly
        df['y'] = np.cumsum(nc*yp - ym/nd - df.d) * ddt + y0

    # --------------------- Calculate the bounds on the state-of-charge ----
    # observe state-of-charge at noon for the decision on new market bids
    if bid_time == 'noon':
        t_obs = tt[0] + datetime.timedelta(hours=12,minutes=00)
        y_obs = df['y'][t_obs-datetime.timedelta(seconds=10)]
        # resample the true state-of-charge dataframe to a 30min resolution
        df_dt = df.resample('30min').mean()
        # define the time range at the end of which the bounds on the
        # ... state-of-charge should hold
        t_est = pd.date_range(t_obs, t[-1], freq='30min')
        # extract the values of the market bids and the power consumption for
        # ... driving for that time range
        d = df_dt.d[t_est]
        xb = np.array(df_dt.xb[t_est].values)
        xr = np.array(df_dt.xr[t_est].values)
        # Estimate the conservative bounds
        y0_max = Calc_y0_max(dt, d, xr, xb, y_obs, nc_plan, gmm, Gmm)
        y0_min = Calc_y0_min(dt, d, xr, xb, y_obs, nc_plan, dn_plan, gmm, Gmm)
        # Estimate the less conservative bounds
        y0_hat_max = Calc_y0_max(dt, d, xr, xb, y_obs, nc_plan, gmmh, Gmmh)
        y0_hat_min = Calc_y0_min(dt, d, xr, xb, y_obs, nc_plan, dn_plan, gmmh, Gmmh)
        # bound the forecasts by the lower and upper bounds on the batter capacity
        y0_min = max(y0_min, y_min)
        y0_hat_min = max(y0_hat_min, y_min)
        y0_max = min(y0_max, y_max)
        y0_hat_max = min(y0_hat_max, y_max)
    elif bid_time == 'midnight':
        # resample the true state-of-charge dataframe to a 30min resolution
        df_dt = df.resample('30min').mean()
        # calculate the bounds
        y0_min = df['y'][-1]
        y0_hat_min = df['y'][-1]
        y0_max = df['y'][-1]
        y0_hat_max = df['y'][-1]

    # --------------------- Return the results -----------------------------
    return {'y0': df['y'][-1], 'y0_min': y0_min, 'y0_max': y0_max,\
            'y0_hat_min': y0_hat_min, 'y0_hat_max': y0_hat_max,\
            'ymin': df['y'].min(), 'ymax': df['y'].max(),\
            'xr_m': df_dt['xr_m'], 'd_m': df_dt['d_m'], 'y': df.loc[t, 'y']}

############################################################################

def Calc_y0_max(dt, d, xr, xb, y0_obs, nc, gmm, Gmm):

#    print('Forecast upper bound on state-of-charge')

    k = len(xr)
#    print('k : '+str(k))

    # Gurobi Model
    m = Model("y0_max")
    # Maximization
    m.ModelSense = -1
    # Decision Variables
    delta = m.addVars(range(k), lb=0, ub=1, obj=nc*xr, name="delta")
    # Constraints
#    for l in range(k):
#        print(str(max(0, l+1 - round(Gmm/dt))) + '--' + str(l))
    m.addConstrs( (quicksum( delta[i] \
                    for i in range( max(0, l+1 - round(Gmm/dt)), l+1)) \
                    <= round(gmm/dt) for l in range(k)), "ymax" )
    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Optimize
    m.optimize()

#    print('obj_val_ymax : ' + str(m.objVal))
#    print('y0_obs : ' + str(y0_obs))
    return y0_obs + (sum(nc*xb - d) + m.objVal)*dt

############################################################################

def Calc_y0_min(dt, d, xr, xb, y0_obs, nc, dn, gmm, Gmm):

#    print('Forecast lower bound on state-of-charge')

    k = len(xr)
#    print('k : '+str(k))
    # Gurobi Model
    m = Model("y0_min")
    # Maximization
    m.ModelSense = -1
    # Decision Variables
    delta = m.addVars(range(k), lb=0, ub=1,\
                      obj= (nc*xr + dn*np.maximum(xr-xb,0)) , name="delta")
    # Constraints
#    for l in range(k):
#        print(str(max(0, l+1 - round(Gmm/dt))) + '--' + str(l))
    m.addConstrs( (quicksum( delta[i] \
                            for i in range( max(0, l+1 - round(Gmm/dt)), l+1)) \
                    <= round(gmm/dt) for l in range(k)), "ymin" )
    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Optimize
    m.optimize()

#    print('obj_val_ymin : ' + str(m.objVal))
    return y0_obs + (sum(nc*xb - d) - m.objVal)*dt

############################################################################

def Reg(pr, pb, d, K, y_max, y_min, yc_max, yd_max,\
        y0_min, y0_max, y0_hat_min, y0_hat_max, phi,\
        nc, nd, dn, dt, gmm, Gmm, gmmh, Gmmh):

#    print('Build optimization problem')

    # Build tuplelist for dual variables
    idx = [(k,l) for k in range(K) for l in range(k+1)]

    # Setup Optimization Model
    m = Model("Reg")

    # Decision Variables and Objective (debug on real regulation prices)
#    xr = m.addVars(range(K), lb=0, obj=-dt*pr['pr'], name="xr")
    xr = m.addVars(range(K), lb=0, obj=-dt*pr['pr_est'], name="xr")
    xb = m.addVars(range(K), lb=0, obj=dt*pb, name="xb")
    yTlh = m.addVar(lb = -GRB.INFINITY, name = 'yTlh')
    yTuh = m.addVar(lb = -GRB.INFINITY, name = 'yTuh')
    z = m.addVar(obj=1, lb=-GRB.INFINITY, name="z")
    # Decision Rule Coefficients
    b = m.addVars(range(K), lb=-GRB.INFINITY, name="b")
    # Dual Variables - Vectors
    lbdp = m.addVars(range(K), lb=0, name="lbdp")
    lbdm = m.addVars(range(K), lb=0, name="lbdlm")
    thtp = m.addVars(range(K), lb=0, name="thtp")
    thtm = m.addVars(range(K), lb=0, name="thtm")
    # Dual Variables - Matrices
    Lbdp = m.addVars(idx, lb=0, name="Lbdp")
    Lbdm = m.addVars(idx, lb=0, name="Lbdm")
    Thtp = m.addVars(idx, lb=0, name="Thtp")
    Thtm = m.addVars(idx, lb=0, name="Thtm")

    # Power Constraints
    m.addConstrs( (xr[k] + xb[k] <= yc_max[k] for k in range(K)), "cmax" )
    m.addConstrs( (xr[k] - xb[k] <= yd_max[k] for k in range(K)), "dmax" )

    # Linearization Constraints
    m.addConstrs( (b[k] >= nc*xr[k] for k in range(K) ), "LDR_1" )
    m.addConstrs( (b[k] >= xr[k]/nd - dn*xb[k] for k in range(K) ), "LDR_2" )

    # Energy Constraints
    m.addConstrs( ( y_max - (quicksum( dt*(nc*xb[l] + Lbdp[k,l] - d[l] ) \
                              + gmm*Thtp[k,l] for l in range(k+1) ))\
                     >= y0_max for k in range(K)), "ymax")

    m.addConstrs( ( y_min - (quicksum( dt*(nc*xb[l] - Lbdm[k,l] - d[l] ) \
                              - gmm*Thtm[k,l] for l in range(k+1) ))\
                     <= y0_min for k in range(K)), "ymin")

    # Epigraph constraints
    # build sets
    N_pos = phi[phi.slope >= 0].index.tolist()
    N_neg = phi[phi.slope < 0].index.tolist()
    # add epigraph constraints
    m.addConstrs( ( phi.slope.loc[n] * yTlh + phi.intercept.loc[n] <= z \
                    for n in N_neg), "z_neg")
    m.addConstrs( ( phi.slope.loc[n] * yTuh + phi.intercept.loc[n] <= z \
                    for n in N_pos), "z_pos")

    # Bounds on the deviation from the initial state-of-charge
    m.addConstr( yTuh - quicksum( dt*(nc*xb[k] + lbdp[k] - d[k] ) + gmmh*thtp[k] \
                          for k in range(K))\
                >= y0_hat_max, 'zh')

    m.addConstr( yTlh - quicksum( dt*(nc*xb[k] - lbdm[k] - d[k]) - gmmh*thtm[k]\
                          for k in range(K))\
                <= y0_hat_min, 'zl')

    # Constraints from Dualization
    m.addConstrs( (Lbdp[k,l] + quicksum( Thtp[k,i] \
                   for i in range(l, 1+I(k, l, Gmm, dt))) \
                   >= nc*xr[l] for (k,l) in idx), "dual_yp")

    m.addConstrs( (Lbdm[k,l] + quicksum( Thtm[k,i] \
                   for i in range(l, 1+I(k, l, Gmm, dt))) \
                   >= b[l] for (k,l) in idx), "dual_ym")

    m.addConstrs( (lbdp[k] + quicksum( thtp[i] \
                   for i in range(k, 1+I(K-1, k, Gmmh, dt))) \
                   >= nc*xr[k] for k in range(K)), "dual_yph")

    m.addConstrs( (lbdm[k] + quicksum( thtm[i] \
                   for i in range(k, 1+I(K-1, k, Gmmh, dt))) \
                   >= b[k] for k in range(K)), "dual_ymh")

    # Disable logging to screen
    m.Params.OutputFlag = 0

#    print('Solve optimization problem')

#   Solve with dual simplex method
    m.Params.Method = 1
    m.optimize()

#    print('Retrieve solution')
#    print('z: '+str(z.X))
    # Update optimal solution
    if m.status == 2:
        # Read optimal variables
        xr_sol = []
        xb_sol = []
        for k in range(0,K):
            xr_sol.append(xr[k].X)
            xb_sol.append(xb[k].X)
        # Evaluate profit on real prices
        profit = dt*sum(pr['pr']*xr_sol - pb * xb_sol)
        # Calculate slope wrt to y0
        # list relevant constraint names
        c_names = ['zl', 'zh']
        c_names_k = ['ymin', 'ymax']
        for i in c_names_k:
            for k in range(K):
                c_names.append(i+'['+str(k)+']')

        dobj_dy0 = 0
        for i in c_names:
            dobj_dy0 = dobj_dy0 + m.getConstrByName(i).Pi
        return {'obj': m.objval, 'dobj_dy0': dobj_dy0, \
        'profit': profit, 'xr': xr_sol, 'xb': xb_sol}

    # Check for infeasibility
    else:
        profit = 'Infeasible'
        return {'profit': profit}

############################################################################

def I(k,l,Gmm,dt):
    return round(min(k, l + Gmm/dt - 1))

############################################################################

def Utl(pb, d, K, y_max, y_min, yc_max, y0, nc, dt, phi):
    # Setup Optimization Model
    m = Model("Utl")

    # Decision Variables and Objective
    xb = m.addVars(range(K), lb=0, ub=yc_max, obj=dt*pb, name='xb')
    yT = m.addVar(lb = -GRB.INFINITY, name = 'yT')
    z = m.addVar(obj=1, name='z')

    # Constraints
    m.addConstrs( ( y_max - dt * quicksum( nc*xb[l] - d[l] for l in range(k+1) ) \
                   >= y0 for k in range(K)), 'ymax')
    m.addConstrs( ( y_min - dt * quicksum( nc*xb[l] - d[l] for l in range(k+1) ) \
                   <= y0 for k in range(K)), 'ymin')

    # Epigraph constraints
    m.addConstrs( ( phi.slope.loc[n] * yT + phi.intercept.loc[n] <= z \
                    for n in phi.index), "z")

    # Terminal State-of-Charge
    m.addConstr( yT - quicksum( dt*(nc*xb[k] - d[k]) for k in range(K) ) \
                    == y0, 'yT' )

    # Disable logging to screen
    m.Params.OutputFlag = 0
    # Solve with dual simplex method
    m.Params.Method = 1
    m.optimize()

    # Check for infeasibility
    if m.status != 2:
        profit = 'Infeasible'
        return {'profit': profit}
    else:
        # Update optimal solution--extract decision variables
        xb_sol = []
        for k in range(0,K):
            xb_sol.append(xb[k].X)
        # Evaluate profit and terminal state-of-charge
        profit = -dt*sum(pb * xb_sol)
        y0 = y0 + dt*sum(nc*np.array(xb_sol) - d)
        # Compute state-of-charge trajectory
        df = pd.DataFrame({'xb': xb_sol, 'd': d})
        df['y'] = y0 + dt*(nc*df.xb.cumsum() - df.d.cumsum())
        # Calculate slope wrt to y0
        # list relevant constraint names
        c_names = ['yT']
        c_names_k = ['ymin', 'ymax']
        for i in c_names_k:
            for k in range(K):
                c_names.append(i+'['+str(k)+']')
        
        dobj_dy0 = 0
        for i in c_names:
            dobj_dy0 = dobj_dy0 + m.getConstrByName(i).Pi
        return {'profit': profit, 'y0': y0, 'xb': xb_sol, 'y': df.y, 'obj': m.objval, 'dobj_dy0': dobj_dy0}                           
############################################################################

def calc_pt_lb(vf, y_low, y_high):
    y_new = (vf.obj.loc[y_low] - vf.obj.loc[y_high] + vf.dobj_dy0.loc[y_high] * y_high
                - vf.dobj_dy0.loc[y_low] * y_low) / (vf.dobj_dy0.loc[y_high] - vf.dobj_dy0.loc[y_low])
    obj_new = vf.dobj_dy0.loc[y_low] * (y_new - y_low) + vf.obj.loc[y_low]
    return y_new, obj_new

def update_yef(yef, vf, lb, Y0_new_lb):
    for y0_new_lb in Y0_new_lb:
        # linear interpolation for the upper bound
        yprev = lb.loc[:y0_new_lb].iloc[-2].name
        ynext = lb.loc[y0_new_lb:].iloc[1].name
        # for debugging
        # ~ print(lb)
        # error calculation
        err = (vf.obj.loc[ynext] - vf.obj.loc[yprev])/(ynext - yprev)*(y0_new_lb - yprev) + vf.obj.loc[yprev] - lb.obj.loc[y0_new_lb]
        # update yef
        yef.loc[y0_new_lb] = err
    # sort yef
    yef.sort_index(inplace = True)
    return yef

def phi2pts(phi, y_min, y_max):
    pts = pd.DataFrame(columns = ['obj']); pts.index.name = 'y0';
    pts.loc[y_min] = phi.iloc[0].intercept + phi.iloc[0].slope * y_min
    for i in range(len(phi) - 1):
        y = (phi.iloc[i].intercept - phi.iloc[i+1].intercept) /\
            (phi.iloc[i+1].slope   - phi.iloc[i].slope)
        obj = phi.iloc[i].slope * y + phi.iloc[i].intercept
        pts.loc[y] = obj
    pts.loc[y_max] = phi.iloc[-1].intercept + phi.iloc[-1].slope * y_max
    return pts

# ----------------------------------------------------------------------

def calc_phi(pr, pb, d, K, y_max, y_min, yc_max, yd_max, phi_1stage, \
             nc_plan, nd_plan, dn_plan, dt, gmm, Gmm, gmmh, Gmmh, \
             N = 15, tol = 0.001, n_dig = 6, market = 'regulation', verbose = False):
    """
    phi, pts, feasible = calc_phi(pr, pb, d, K, y_max, y_min, yc_max, yd_max, phi_1stage, \
             nc_plan, nd_plan, dn_plan, dt, gmm, Gmm, gmmh, Gmmh, \
             N = 15, tol = 0.001, n_dig = 6, verbose = False):
    Input:
    - the usual parameters +
    - max. nb of points for representing phi: N
    - max. admissible absolute error on phi: tol
    - number of relevant decimal digits: n_dig (for float comparison)
    - market: either 'regulation' (default) or 'utility'
    - verbose: false by default
    Output:
    - value function represented by affine fcts (phi) and by points (pts
        as well as feasibility statement
    """
    # for debugging
    # ~ print('This is the beginning of calc_phi')
    # --------------------- start function value function iteration definition
    # define verbosity
    if verbose:
        def verboseprint(my_text):
            print(my_text)
    else:
        verboseprint = lambda *a: None

    # --------------------- declare results
    # known parameters about the value function
    vf = pd.DataFrame(columns=['y0', 'obj', 'dobj_dy0'])
    vf.set_index('y0', inplace = True)

    # list of points at which the lower bound is to be calculated
    Y0_new_lb = []

    # known points about the lower bound
    lb = pd.DataFrame(columns=['obj']); lb.index.name = 'y0'

    # max. estimation error by number of pts in the upper bound
    ef = pd.DataFrame(columns=['pts', 'max_err'])

    # estimation error by y0
    yef = pd.DataFrame(columns=['err']); yef.index.name = 'y0'

    # --------------------- initialization
    # initialize the value function: compute it for the extreme values y0 equal to 0 and 1
    for y0 in [y_min, y_max]:
        if market == 'regulation':
            res_y0 = Reg(pr=pr, pb=pb, d=d, K=K,\
                              y_max = y_max,y_min=y_min,yc_max=yc_max,yd_max=yd_max,\
                              y0_min = y0, y0_max = y0,\
                              y0_hat_min = y0, y0_hat_max = y0,\
                              phi = phi_1stage,\
                              nc=nc_plan,nd=nd_plan, dn=dn_plan, dt=dt,\
                              gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh)
        elif market == 'utility':
            res_y0 = Utl(pb=pb, d=d, K=K, y_max = y_max, y_min = y_min,\
                         yc_max = yc_max, y0 = y0, nc = nc_plan, dt = dt, phi = phi_1stage)
        else:
            print('ERROR: \'market\' must be either \'regulation\' or \'utility\'')
            return ['Infeasible', 'Infeasible', False]
        # check for feasibility
        if res_y0['profit'] == 'Infeasible':
            print('ERROR: Value function estimation is infeasible')
            return ['Infeasible', 'Infeasible', False]
        # update vf and lb
        vf.loc[y0] = [res_y0['obj'], res_y0['dobj_dy0']]
        lb.loc[y0] = res_y0['obj']

    # calculate a new point for the lower bound if the value function is not just one linear piece
    if round(vf.loc[y_min].dobj_dy0, n_dig) != round(vf.loc[y_max].dobj_dy0, n_dig):
        y0_new_lb, obj_new_lb = calc_pt_lb(vf, y_min, y_max)

    # check if we have actually calculated a new point (not necessarily the case because the dual variable dobj_dy0 gives a subdifferential)
    if (y_min + 10**(-n_dig) < y0_new_lb) & (y0_new_lb < y_max - 10**(-n_dig)):
        Y0_new_lb.append(y0_new_lb)
        lb.loc[y0_new_lb] = obj_new_lb
        lb.sort_index(inplace = True)

    # update the error dataframe
    yef = update_yef(yef, vf, lb, Y0_new_lb)

    # update max error for a given number of points in the value function
    if not yef.empty:
        ef.loc[len(ef)] = [len(vf), max(yef.err)]
    else:
        ef.loc[len(ef)] = [len(vf), 0]

    # cnt for debugging
    cnt = 1

    # --------------------- iterations
    while (ef.max_err.iloc[-1] > tol) & (len(vf) < N):
        verboseprint('\n-----------------------------------------')
        verboseprint('++++++++ iteration: '+str(cnt)+' ++++++++')
        verboseprint('-----------------------------------------')
        # start a list Y0_new_vf with all those value of y0 that have an error greater than tol and remove these values from the dataframe yef
        Y0_new_vf = np.array(yef.loc[yef.err > tol].index)
        yef = yef.loc[yef.err <= tol]

        # evaluate the function at all points whose error is higher than tol
        for y0_new_vf in Y0_new_vf:
            # calculate value function at y0_new_vf and update vf and lb
            if market == 'regulation':
                res_y0 = Reg(pr=pr, pb=pb, d=d, K=K,\
                              y_max = y_max,y_min=y_min,yc_max=yc_max,yd_max=yd_max,\
                              y0_min = y0_new_vf, y0_max = y0_new_vf,\
                              y0_hat_min = y0_new_vf, y0_hat_max = y0_new_vf,\
                              phi = phi_1stage,\
                              nc=nc_plan,nd=nd_plan, dn=dn_plan, dt=dt,\
                              gmm = gmm, Gmm = Gmm, gmmh = gmmh, Gmmh = Gmmh)
            elif market == 'utility':
                res_y0 = Utl(pb=pb, d=d, K=K, y_max = y_max, y_min = y_min,\
                             yc_max = yc_max, y0 = y0, nc = nc_plan, dt = dt, phi = phi_1stage)
            else:
                print('ERROR: \'market\' must be either \'regulation\' or \'utility\'')
                return ['Infeasible', 'Infeasible', False]
            # check for feasibility
            if res_y0['profit'] == 'Infeasible':
                print('ERROR: Value function estimation is infeasible')
                return ['Infeasible', 'Infeasible', False]
            # add new values to vf
            vf.loc[y0_new_vf] = [res_y0['obj'], res_y0['dobj_dy0']]
            # update existing values in lb
            lb.loc[y0_new_vf] = res_y0['obj']
        # sort the value function dataframe (the lb dataframe is already sorted, its values are only updated)
        vf.sort_index(inplace = True)

        # for debugging: print value function
        verboseprint('\n---- value function: ')
        verboseprint(vf)

        # calculate new points for the lower bounds
        verboseprint('\n---- new candidate points for the lower bound: ')
        Y0_new_lb = []

        # calculate neighbors to every y0_new_vf in Y0_new_vf
        for y0_new_vf in Y0_new_vf:
            yprev = vf.loc[:y0_new_vf].iloc[-2].name
            ynext = vf.loc[y0_new_vf:].iloc[1].name

            # compute the corresponding new points for the lower bound if the points are not on the same linear piece
            # - between yprev and y0_new_vf
            if round(vf.loc[yprev].dobj_dy0, n_dig) != round(vf.loc[y0_new_vf].dobj_dy0, n_dig):
                y0_new_lb, obj_new_lb = calc_pt_lb(vf, yprev, y0_new_vf)
                # check if we have actually calculated a new point (not necessarily the case because the dual variable dobj_dy0 gives a subdifferential)
                if (yprev + 10**(-n_dig) < y0_new_lb) & (y0_new_lb < y0_new_vf - 10**(-n_dig)):
                    Y0_new_lb.append(y0_new_lb); lb.loc[y0_new_lb] = obj_new_lb
                    verboseprint('y0_new_lb: ' + str(round(y0_new_lb, n_dig)))
            # - between y0_new_vf and ynext
            if round(vf.loc[ynext].dobj_dy0, n_dig) != round(vf.loc[y0_new_vf].dobj_dy0, n_dig):
                y0_new_lb, obj_new_lb = calc_pt_lb(vf, y0_new_vf, ynext)
                # check if we have actually calculated a new point (not necessarily the case because the dual variable dobj_dy0 gives a subdifferential)
                if (y0_new_vf + 10**(-n_dig) < y0_new_lb) & (y0_new_lb < ynext - 10**(-n_dig)):
                    Y0_new_lb.append(y0_new_lb); lb.loc[y0_new_lb] = obj_new_lb
                    verboseprint('y0_new_lb: ' + str(round(y0_new_lb, n_dig)))

        # check if Y0_new_lb is nonempty
        if not(not Y0_new_lb):
            # sort lower bound
            lb.sort_index(inplace = True)
            # update the error dataframe
            yef = update_yef(yef, vf, lb, Y0_new_lb)

        # for debugging: print intermediate results
        verboseprint('\n---- lower bound: ')
        verboseprint(lb)
        # ~ print('\n---- new points for the lower bound')
        # ~ print(np.around(Y0_new_lb, n_dig))

        # update max error for a given number of points in the value function
        if not yef.empty:
            ef.loc[len(ef)] = [len(vf), max(yef.err)]
        else:
            ef.loc[len(ef)] = [len(vf), 0]

        # for debugging: print error information
        verboseprint('\n---- errors at evaluation points')
        verboseprint(yef)
        verboseprint('\n---- error evolution:')
        verboseprint(ef)

        # for debugging: avoid infinite loop
        cnt = cnt + 1
        # --- end of while loop

    # --------------------- analyze results
    # print results
    verboseprint('\n-----------------------------------------')
    verboseprint('++++++++++++++++ results ++++++++++++++++')
    verboseprint('-----------------------------------------')
    verboseprint('\n---- value function: ')
    verboseprint(vf)
    verboseprint('\n---- lower bound: ')
    verboseprint(lb)
    verboseprint('\n---- error evolution:')
    verboseprint(ef)
    verboseprint('\n---- errors at evaluation points')
    verboseprint(yef)

    # plot results
    # ~ plt.plot(vf['obj'])
    # ~ plt.plot(lb)
    # ~ plt.grid()
    # ~ plt.show()

    # --------------------- compare with original value function
    # ~ plt.plot([y_, ystar, y], [pstar*(ystar - y_), 0, pstar*(y - ystar)],
             # ~ label = 'original')
    # ~ plt.plot(vf.obj, label = 'new')
    # ~ plt.grid()
    # ~ plt.legend()
    # ~ plt.show()

    # --------------------- represent vf by affine functions
    dy = np.diff(vf.index.values)
    dobj = (vf.obj.diff(-1)).values[:-1]
    slopes = - dobj/dy
    intercepts = vf.obj.values[:-1] - slopes * vf.index.values[:-1]
    phi = pd.DataFrame({'slope': slopes, 'intercept': intercepts})
    # clean phi of duplicates: occur if vf is evaluated more than once on the same linear piece
    phi['difference'] = phi.diff().max(axis = 1).round(n_dig)
    phi = phi[['slope', 'intercept']][phi.difference != 0]
    verboseprint('\n---- value function representation')
    verboseprint(phi)
    verboseprint('\n---- shortened point representation')
    pts = phi2pts(phi, y_min, y_max)
    verboseprint(pts)
    # for debugging
    # ~ print('This is the end of calc_phi')
    # ~ print(pts)
    return [phi, pts, True]

# ----------------------------------------------------------------------
